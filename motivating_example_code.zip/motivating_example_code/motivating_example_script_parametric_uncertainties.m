clear all
close all
clc

rng(111); % random generator seed for reproducibility
a = -2;
b =  2;
c = -1;
uRange = [0:0.01:5];
fValues = zeros(size(uRange));

for i = 1 : length(uRange)
    fValues(i) = MotivatingExampleModel(uRange(i),[a;b;c]);
end

figure(1)
hold on
grid on
plot(uRange, fValues,'k', 'LineWidth',3.0);

figure(5)
hold on
grid on
plot(uRange, fValues,'k', 'LineWidth',3.0);

% sampling

uSamples = [1.25,2.5,4,4.5,5];
fSamples = zeros(size(uSamples));

for i = 1 : length(uSamples)
    fSamples(i) = MotivatingExampleModel(uSamples(i),[a;b;c]) + 0.1*randn();
end

% fitting

[thEst,covMatrix] = FitParametersToModel([a;b;c],uSamples',fSamples');

% draw fitted model

fValuesEst = fValues;

for i = 1 : length(uRange)
    fValuesEst(i) = MotivatingExampleModel(uRange(i),thEst);
end

figure(1)
hold on
grid on
plot(uRange, fValuesEst,'b', 'LineWidth',2.0);

figure(5)
hold on
grid on
plot(uRange, fValuesEst,'b', 'LineWidth',2.0);

% GP regression

gprMdl1 = fitrgp(uSamples', fSamples','KernelFunction','squaredexponential','Sigma',0.1,'ConstantSigma',true);
[ypred1,~,yint1] = predict(gprMdl1,uRange');


figure(5)
hold on
plot(uRange',ypred1,'color',[0.9290 0.6940 0.1250],'LineWidth', 2.0) % GPR predictions
hold on
patch([uRange';flipud(uRange')],[yint1(:,1);flipud(yint1(:,2))],'k','FaceAlpha',0.1); % Prediction intervals
hold off

for i = 1 : length(uSamples)
    figure(1)
    hold on
    scatter(uSamples(i),fSamples(i),60,'rsquare','filled');
    figure(5)
    hold on
    scatter(uSamples(i),fSamples(i),60,'rsquare','filled');
end


%% best and worst case with model

uRangeWBC = 0:0.01:5; 
[wcc,bcc] = GetWorstBestCases(thEst,covMatrix,uRangeWBC);

% Initial model with uncertainty bounds

figure(1)
hold on
plot(uRangeWBC,wcc,'--','Color',[1,0.65,0],'LineWidth',2.0);
plot(uRangeWBC,bcc,'--','Color',[1,0.65,0],'LineWidth',2.0);
axis([0,5,-11,11]);

for i = 1 : length(uSamples)
    figure(1)
    hold on
    scatter(uSamples(i),fSamples(i),60,'rsquare','filled');
    figure(5)
    hold on
    scatter(uSamples(i),fSamples(i),60,'rsquare','filled');
end

% Find robust optimum
roboptValue = min(wcc);
roboptInputIndex = find(wcc==roboptValue);
roboptInput = uRangeWBC(roboptInputIndex);

figure(1)
hold on
scatter(roboptInput,roboptValue,100,'cp','filled');

% Two batches of one experiment and consequent models/bounds
for k = 1 : 2
    roboptValue = min(wcc);
    roboptInputIndex = find(wcc==roboptValue);
    roboptInput = uRangeWBC(roboptInputIndex);
    figure(k)
    hold on
    scatter(roboptInput,roboptValue,100,'cp','filled');
    varVal = wcc-bcc;
    expImprovement = roboptValue-(wcc+bcc)/2;
    for i = 1 : length(expImprovement)
        expImprovement(i) = max([0,expImprovement(i)]);
    end
    
    expimpWeighted = varVal.*expImprovement; 
    [~,optimalExperimentIndex] = max(expimpWeighted);
    optimalExperimentInput = uRangeWBC(optimalExperimentIndex);

    figure(k+5)
    hold on
    grid on
    plot(uRangeWBC,expimpWeighted,'k','LineWidth',2.0)
    xlabel('u');
    ylabel('Acquisition Function');
    uSamples = [uSamples, optimalExperimentInput];
    fSamples = [fSamples, MotivatingExampleModel(optimalExperimentInput, [a;b;c])+0.1*randn()];
    [thEst,covMatrix] = FitParametersToModel([a;b;c],uSamples',fSamples');

    figure(k+1)
    hold on
    grid on
    plot(uRange, fValues,'k', 'LineWidth',3.0);
    fValuesEst = fValues;    
    for i = 1 : length(uRange)
        fValuesEst(i) = MotivatingExampleModel(uRange(i),thEst);
    end

    figure(k+1)
    hold on
    grid on
    plot(uRange, fValuesEst,'b', 'LineWidth',2.0);
    [wcc,bcc] = GetWorstBestCases(thEst,covMatrix,uRangeWBC);

    figure(k+1)
    hold on
    plot(uRangeWBC,wcc,'--','Color',[1,0.65,0],'LineWidth',2.0);
    plot(uRangeWBC,bcc,'--','Color',[1,0.65,0],'LineWidth',2.0);
    for j = 1 : length(uSamples)-1
        scatter(uSamples(j),fSamples(j),60,'rsquare','filled');
    end
    scatter(uSamples(end),fSamples(end),60,'gdiamond','filled');
end

% Adding labels to figure axis
figure(1)
hold on
xlabel('u')
ylabel('f(u)')
figure(2)
hold on
xlabel('u')
ylabel('f(u)')
figure(3)
hold on
xlabel('u')
ylabel('f(u)')
figure(5)
hold on
xlabel('u')
ylabel('f(u)')

function [wcc,bcc] = GetWorstBestCases(thEst,covMatrix,uRange)    
    %worst case
    wcc = zeros(size(uRange));
    bcc = wcc;
    wb = waitbar(0,'Evaluating Best and Worst Cases...');
    options = optimoptions('fmincon','SpecifyConstraintGradient',true,'SpecifyObjectiveGradient',false,'CheckGradients',false);
    thWorst = thEst;
    thBest = thEst;
    for i = 1 : length(uRange)
        waitbar(i/length(uRange),wb,'Evaluating Best and Worst Cases...')
        [thWorst,wcc(i)] = fmincon(@(th)(ObjEvaluationWorstCase(uRange(i),th)),thWorst,[],[],[],[],[],[],@(th)(uncSetConstraints(th,thEst,covMatrix)),options);
        [thBest,bcc(i)] = fmincon(@(th)(ObjEvaluationBestCase(uRange(i),th)),thBest,[],[],[],[],[],[],@(th)(uncSetConstraints(th,thEst,covMatrix)),options);        
    end
    wcc = -wcc;
    close(wb);
end

function [f,df] = ObjEvaluationWorstCase(u,th)
    a = th(1); b = th(2); c = th(3);
    f = -MotivatingExampleModel(u,th);
end

function [f,df] = ObjEvaluationBestCase(u,th)
    a = th(1); b = th(2);c = th(3);
    f = MotivatingExampleModel(u,th);
end

function [c,ceq,dc,dceq] = uncSetConstraints(th,thEst,covMatrix)
    P = inv(covMatrix);
    rho = chi2inv(0.95,3);
    ceq = [];
    c = (th-thEst)'*P*(th-thEst)-rho;
    dc =  2*P*(th-thEst);
    dceq = [];
end

function [thEst,covMatrix] = FitParametersToModel(thetaInit,uSamples,fSamples)
    options = optimoptions('lsqcurvefit','SpecifyObjectiveGradient',false,'CheckGradients',true);
    [thEst,resnorm,~,~,~,~,J] = lsqcurvefit(@(th,u)FitModelFunction(th,u),thetaInit,uSamples,fSamples,[],[],options);
    covMatrix = inv(J'*J)*resnorm/length(uSamples);
end

function [f,df] = FitModelFunction(th,uS)
    f = [];
    df = [];
    a = th(1); b = th(2); c = th(3);
    for i = 1 : length(uS)
        u = uS(i);
        f = [f;MotivatingExampleModel(uS(i),th)];
    end
    
end

function wm = MotivatingExampleModel(u,th)
    a = th(1);
    b = th(2);
    c = th(3);
    wm = a*exp(-((u-1)*2)^2) +  b*exp(-((u-1.5)*2)^2) + c*exp(-((u-3)*1)^2);
end
