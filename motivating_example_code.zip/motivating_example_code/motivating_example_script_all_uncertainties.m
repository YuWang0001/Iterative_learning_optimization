clear all
close all
clc

rng(111); % random generator seed for reproducibility
a = -2;
b =  2;
c = -1;
uRange = [0:0.01:5];
fValues = zeros(size(uRange));

for i = 1 : length(uRange)
    fValues(i) = MotivatingExampleModel(uRange(i),[a;b;c]);
end

figure(1)
hold on
grid on
plot(uRange, fValues,'k', 'LineWidth',3.0);


% sampling

uSamples = [1.25,2.5,4,4.5,5];
fSamples = zeros(size(uSamples));
for i = 1 : length(uSamples)
    fSamples(i) = MotivatingExampleModel(uSamples(i),[a;b;c]) + 0.1*randn();
end

% fitting

[thEst,covMatrix] = FitParametersToModel([a;b;c],uSamples',fSamples');

% draw fitted model

fValuesEst = fValues;

for i = 1 : length(uRange)
    fValuesEst(i) = MotivatingExampleModel(uRange(i),thEst);
end
figure(1)
hold on
grid on
plot(uRange, fValuesEst,'b', 'LineWidth',2.0);


for i = 1 : length(uSamples)
    figure(1)
    hold on
    scatter(uSamples(i),fSamples(i),60,'rsquare','filled');
end


%% best and worst case with model
uRangeWBC = 0:0.01:5;
[wcc,bcc,thWorstMatrix,thBestMatrix] = GetWorstBestCases(thEst,covMatrix,uRangeWBC);
[wccTotal,bccTotal] = GetWorstBestCasesTotal(thEst,covMatrix,uRangeWBC,thWorstMatrix,thBestMatrix);


% Initial model with uncertainty bounds

figure(1)
hold on
plot(uRangeWBC,wcc,'--','Color',[1,0.65,0],'LineWidth',2.0);
plot(uRangeWBC,bcc,'--','Color',[1,0.65,0],'LineWidth',2.0);
plot(uRangeWBC,wccTotal,'--','Color',[0.7,0.7,0.7],'LineWidth',2.0);
plot(uRangeWBC,bccTotal,'--','Color',[0.7,0.7,0.7],'LineWidth',2.0);

for i = 1 : length(uSamples)
    figure(1)
    hold on
    scatter(uSamples(i),fSamples(i),60,'rsquare','filled');
end

% Two batches of one experiment and consequent models/bounds

for k = 1 : 2
    % Find robust optimum

    roboptValue = min(wccTotal);
    roboptInputIndex = find(wccTotal==roboptValue);
    roboptInput = uRangeWBC(roboptInputIndex);
    figure(k)
    hold on
    scatter(roboptInput,roboptValue,100,'cp','filled');
    varVal = wcc-bcc;
    varTotalVal = wccTotal - bccTotal;
    expImprovement = roboptValue-(wccTotal+bccTotal)/2;
    for i = 1 : length(expImprovement)
        expImprovement(i) = max([0,expImprovement(i)]);
    end
    
    expimpWeighted = varTotalVal.*expImprovement./(abs(varTotalVal-varVal)+1); 
    [~,optimalExperimentIndex] = max(expimpWeighted);
    optimalExperimentInput = uRangeWBC(optimalExperimentIndex);
    figure(k+5)
    hold on
    grid on
    plot(uRangeWBC,expimpWeighted,'k','LineWidth',2.0)
    xlabel('u');
    ylabel('Acquisition Function');
    uSamples = [uSamples, optimalExperimentInput+(0.5-rand())];
    fSamples = [fSamples, MotivatingExampleModel(uSamples(end), [a;b;c])+0.1*randn()];
    [thEst,covMatrix] = FitParametersToModel([a;b;c],uSamples',fSamples');
    figure(k+1)
    hold on
    grid on
    plot(uRange, fValues,'k', 'LineWidth',3.0);
    fValuesEst = fValues;    
    for i = 1 : length(uRange)
        fValuesEst(i) = MotivatingExampleModel(uRange(i),thEst);
    end
    figure(k+1)
    hold on
    grid on
    plot(uRange, fValuesEst,'b', 'LineWidth',2.0);

    [wcc,bcc,thWorstMatrix,thBestMatrix] = GetWorstBestCases(thEst,covMatrix,uRangeWBC);
    [wccTotal,bccTotal] = GetWorstBestCasesTotal(thEst,covMatrix,uRangeWBC,thWorstMatrix,thBestMatrix);
    figure(k+1)
    hold on
    plot(uRangeWBC,wcc,'--','Color',[1,0.65,0],'LineWidth',2.0);
    plot(uRangeWBC,bcc,'--','Color',[1,0.65,0],'LineWidth',2.0);
    plot(uRangeWBC,wccTotal,'--','Color',[0.7,0.7,0.7],'LineWidth',2.0);
    plot(uRangeWBC,bccTotal,'--','Color',[0.7,0.7,0.7],'LineWidth',2.0);
    for j = 1 : length(uSamples)-1
        scatter(uSamples(j),fSamples(j),60,'rsquare','filled');
    end
    scatter(optimalExperimentInput,MotivatingExampleModel(optimalExperimentInput,[a;b;c]),60,'mv','filled');
    scatter(uSamples(end),fSamples(end),60,'gdiamond','filled');
end

% Adding labels to figure axis

figure(1)
hold on
xlabel('u')
ylabel('f(u)')
figure(2)
hold on
xlabel('u')
ylabel('f(u)')
figure(3)
hold on
xlabel('u')
ylabel('f(u)')
figure(5)
hold on
xlabel('u')
ylabel('f(u)')

function [wcc,bcc,thWorstMatrix,thBestMatrix] = GetWorstBestCases(thEst,covMatrix,uRange)
    %worst case
    wcc = zeros(size(uRange));
    bcc = wcc;
    thWorstMatrix = zeros(3,length(uRange));
    thBestMatrix = thWorstMatrix;
    wb = waitbar(0,'Evaluating Best and Worst Cases w. Parameter Unc. ...');
    options = optimoptions('fmincon','SpecifyConstraintGradient',true,'SpecifyObjectiveGradient',true,'CheckGradients',false);
    thWorst = thEst;
    thBest = thEst;
    for i = 1 : length(uRange)
        waitbar(i/length(uRange),wb,'Evaluating Best and Worst Cases w. Parameter Unc. ...')
        [thWorst,wcc(i)] = fmincon(@(th)(ObjEvaluationWorstCase(uRange(i),th)),thWorst,[],[],[],[],[],[],@(th)(uncSetConstraints(th,thEst,covMatrix)),options);
        [thBest,bcc(i)] = fmincon(@(th)(ObjEvaluationBestCase(uRange(i),th)),thBest,[],[],[],[],[],[],@(th)(uncSetConstraints(th,thEst,covMatrix)),options);        
        thWorstMatrix(:,i) = thWorst;
        thBestMatrix(:,i) = thBest;
    end
    close(wb);
    wcc = -wcc;
end

function [f,df] = ObjEvaluationWorstCase(u,th)
    a = th(1); b = th(2); c = th(3);
    f = -MotivatingExampleModel(u,[th]);

    df = -[exp(-((u-1)*2)^2);
          exp(-((u-1.5)*2)^2);
          exp(-((u-3)*1)^2)];
end
function [f,df] = ObjEvaluationBestCase(u,th)
    a = th(1); b = th(2);c = th(3);
    f = MotivatingExampleModel(u,th);
    df = [exp(-((u-1)*2)^2);
          exp(-((u-1.5)*2)^2);
          exp(-((u-3)*1)^2)];
end

function [c,ceq,dc,dceq] = uncSetConstraints(th,thEst,covMatrix)
    P = inv(covMatrix);
    rho = chi2inv(0.99,3);
   ceq = [];
   c = (th-thEst)'*P*(th-thEst)-rho;
    dc =  2*P*(th-thEst);
    dceq = [];
end

function [wcc,bcc] = GetWorstBestCasesInput(thEst,covMatrix,uRange,thWorstMatrix,thBestMatrix)
    %worst case
    wcc = zeros(size(uRange));
    bcc = wcc;
    wb = waitbar(0,'Evaluating Best and Worst Cases w. Input Unc. ...');
    options = optimoptions('fmincon','SpecifyConstraintGradient',true,'SpecifyObjectiveGradient',false,'CheckGradients',false);
    thWorst = thEst;
    thBest = thEst;
    uWorst = uRange(1);
    uBest = uRange(1);
    for i = 1 : length(uRange)
        waitbar(i/length(uRange),wb,'Evaluating Best and Worst Cases w. Input Unc. ...')
        [uWorst,wcc(i)] = fmincon(@(u)(ObjEvaluationWorstCaseInput(u,thEst)),uWorst,[],[],[],[],[uRange(i)-0.5],[uRange(i)+0.5],[],options);
        [uBest,bcc(i)] = fmincon(@(u)(ObjEvaluationBestCaseInput(u,thEst)),uBest,[],[],[],[],[uRange(i)-0.5],[uRange(i)+0.5],[],options);
    end
    close(wb);
    wcc = -wcc;
end

function [f,df] = ObjEvaluationWorstCaseInput(u,th)
    a = th(1); b = th(2); c = th(3);
    f = -MotivatingExampleModel(u,th);
end
function [f,df] = ObjEvaluationBestCaseInput(u,th)
    a = th(1); b = th(2);c = th(3);
    f = MotivatingExampleModel(u,th);
end

function [c,ceq,dc,dceq] = uncSetConstraintsInput(u,uNom)
   ceq = [];
   c = [ u-uNom-0.5;
        -u+uNom-0.5];
    dc =  [1,-1];
    dceq = [];
end


function [wcc,bcc] = GetWorstBestCasesTotal(thEst,covMatrix,uRange,thWorstMatrix,thBestMatrix)
    c = 1.75;
    %worst case
    wcc = zeros(size(uRange));
    bcc = wcc;
    wb = waitbar(0,'Evaluating Best and Worst Cases both unc. ...');
    options = optimoptions('fmincon','SpecifyConstraintGradient',true,'SpecifyObjectiveGradient',true,'CheckGradients',false);
    thWorst = thEst;
    thBest = thEst;
    for i = 1 : length(uRange)
        uWorst = uRange(i);
        uBest = uRange(i);
        thWorst = thWorstMatrix(:,i);
        thBest = thBestMatrix(:,i);
        waitbar(i/length(uRange),wb,'Evaluating Best and Worst Cases both unc. ...')
        [zWorst,wcc(i)] = fmincon(@(z)(ObjEvaluationWorstCaseTotal(z(1),z(2:end))),[uWorst;thWorst],[],[],[],[],[],[],@(z)(uncSetConstraintsTotal(z(1),z(2:end),uRange(i),thEst,covMatrix)),options);
        [zBest,bcc(i)] = fmincon(@(z)(ObjEvaluationBestCaseTotal(z(1),z(2:end))),[uBest;thBest],[],[],[],[],[],[],@(z)(uncSetConstraintsTotal(z(1),z(2:end),uRange(i),thEst,covMatrix)),options);
    end
    close(wb);
    wcc = -wcc;
end

function [f,df] = ObjEvaluationWorstCaseTotal(u,th)
    a = th(1); b = th(2); c = th(3);
    f = -MotivatingExampleModel(u,[th]);
    df = -[-2*c*exp(-(-3+u)^2)*(-3+u)-8*b*exp(-4*(-1.5+u)^2)*(-1.5+u)-8*a*exp(-4*(-1+u)^2)*(-1+u);
          exp(-((u-1)*2)^2);
          exp(-((u-1.5)*2)^2);
          exp(-((u-3)*1)^2)];
end

function [f,df] = ObjEvaluationBestCaseTotal(u,th)
    a = th(1); b = th(2);c = th(3);
    f = MotivatingExampleModel(u,th);
    df = [-2*c*exp(-(-3+u)^2)*(-3+u)-8*b*exp(-4*(-1.5+u)^2)*(-1.5+u)-8*a*exp(-4*(-1+u)^2)*(-1+u);
          exp(-((u-1)*2)^2);
          exp(-((u-1.5)*2)^2);
          exp(-((u-3)*1)^2)];
end

function [c,ceq,dc,dceq] = uncSetConstraintsTotal(u,th,uNom,thEst,covMatrix)
    P = inv(covMatrix);
    rho = chi2inv(0.99,3);
   ceq = [];
   c = [(th-thEst)'*full(P)*(th-thEst)-rho; 
        u-uNom-0.5;
        -u+uNom-0.5];
    dc =  [0,1,-1;
           2*full(P)*(th-thEst),zeros(3,1),zeros(3,1)];
    dceq = [];
end


function [thEst,covMatrix] = FitParametersToModel(thetaInit,uSamples,fSamples)
    options = optimoptions('lsqcurvefit','SpecifyObjectiveGradient',false,'CheckGradients',true);
    [thEst,resnorm,residuals,~,~,~,J] = lsqcurvefit(@(th,u)FitModelFunction(th,u),thetaInit,uSamples,fSamples,[],[],options);
    covMatrix = inv(J'*J)*resnorm/length(uSamples);
end

function [f,df] = FitModelFunction(th,uS)
    f = [];
    df = [];
    a = th(1); b = th(2); c = th(3);
    for i = 1 : length(uS)
        u = uS(i);
        f = [f;MotivatingExampleModel(uS(i),th)];
    end
    
end

function wm = MotivatingExampleModel(u,th)
    a = th(1);
    b = th(2);
    c = th(3);
    wm = a*exp(-((u-1)*2)^2) +  b*exp(-((u-1.5)*2)^2) + c*exp(-((u-3)*1)^2);
end
