clc;
clear all
close all;

rng(1);

%% Model data
model_data.theta = xlsread('activation_inhibition_coefficients_mod.xlsx','parameters_matrix_complete');

model_data.F = 1;
model_data.Xv = 21.7303;  
model_data.V = 1;

%% Read identified model as true network
[model_data.Amac,~,raw] = xlsread('Amac_matrix_corrected.xlsx','Sheet1'); % read Amac matrix
headers=raw(1,2:end); % get the metabolic names and orders from xlsx files
model_data.Amac =  model_data.Amac';

[data,~,raw] = xlsread('LargeM_d vs RedM_final.xlsx','RedM_final'); 
model_data.w_max=data(3:end,1); % get maximal rates
kinetic_group = data(3:end,3); % get kinetic order
code = raw(3:end,4); % get reaction codes

[para_inh_temp,~,raw] = xlsread('LargeM_d vs RedM_final.xlsx','Sheet1'); % get parameters

para_sat = zeros(1,23);
para_inh = zeros(132,23);

para_sat(10) = 0.83; para_sat(11) = 9.3; para_sat(12) = 6.2; para_sat(5) = 0.22;
para_sat(6) = 0.015; para_sat(13) = 1.7; para_sat(13) = 4.7; para_sat(15) = 0.7;
para_sat(16) = 0.96; para_sat(17) = 0.1; para_sat(18) = 5; para_sat(4) = 0.011;
para_sat(19) = 10.4; para_sat(1) = 0.056; para_sat(9) = 0.07; para_sat(8) = 0.21;
para_sat(2) = 0.02; para_sat(3) = 0.02; para_sat(7) = 0.036; para_sat(20) = 1.66;
para_sat(21) = 13;

para_inh(:,1) = para_inh_temp(:,10) + para_inh_temp(:,33);
para_inh(:,2) = para_inh_temp(:,12) + para_inh_temp(:,35);
para_inh(:,3) = para_inh_temp(:,14) + para_inh_temp(:,37);
para_inh(:,4) = para_inh_temp(:,16) + para_inh_temp(:,39);
para_inh(:,5) = zeros(132,1);
para_inh(:,6) = zeros(132,1);
para_inh(:,7) = zeros(132,1);
para_inh(:,8) = zeros(132,1);
para_inh(:,9) = para_inh_temp(:,13) + para_inh_temp(:,36);
para_inh(:,10) = para_inh_temp(:,18) + para_inh_temp(:,41);
para_inh(:,11) = para_inh_temp(:,2) + para_inh_temp(:,25);
para_inh(:,12) = para_inh_temp(:,17) + para_inh_temp(:,40);
para_inh(:,13) = para_inh_temp(:,15) + para_inh_temp(:,38);
para_inh(:,14) = para_inh_temp(:,11) + para_inh_temp(:,34);
para_inh(:,15) = para_inh_temp(:,9) + para_inh_temp(:,32);
para_inh(:,16) = para_inh_temp(:,5) + para_inh_temp(:,28);
para_inh(:,17) = para_inh_temp(:,1) + para_inh_temp(:,24);
para_inh(:,18) = para_inh_temp(:,6) + para_inh_temp(:,29);
para_inh(:,19) = para_inh_temp(:,7) + para_inh_temp(:,30);
para_inh(:,20) = para_inh_temp(:,8) + para_inh_temp(:,31);
para_inh(:,21) = para_inh_temp(:,3) + para_inh_temp(:,26);
para_inh(:,22) = para_inh_temp(:,4) + para_inh_temp(:,27);
para_inh(:,23) = zeros(132,1);
model_data.para_sat_matrix = GenerateSaturationCoeffMatrix(model_data.Amac,model_data.w_max,kinetic_group,code,para_sat,para_inh,ones(23,1));
model_data.theta(:,1) = model_data.theta(:,1)/10.81; 
%% Optimization setup
opt_data.noConditions = 15;
opt_data.percErrXv = 0; opt_data.percErrMedium = 0; opt_data.percErrConc = 0; opt_data.percErrRates = 0.1; opt_data.Xv_variation = 0;
opt_data.constraint_of_interest = [13;22];
opt_data.rate_of_interest = [opt_data.constraint_of_interest;23];
opt_data.constraint_bounds = [3.5;0.2];  
opt_data.input_bounds = [1,9; ...
                         1,9];
opt_data.alpha = 1; % Tuning parameter for size of uncertainty set

medium = [4	;
    4	;
    2	;
    2.5	;
    4	;
    3	;
    3	;
    5	;
    4	;
    5;   % Ser == 10     
    8; % Asn == 11
    4	;
    2.5	;
    0	;
    1	;
    2	;
    0	;
    60	;
    2	;   % Gln == 19
    5; %Glu == 20
    4	; % Asp == 19
    0	;
    0];


% Substrates to be optimized 
opt_data.Index_input_1 = 11; opt_data.Index_input_2 = 19; 

% Initial parameter values for model update
opt_data.theta_init = model_data.theta;
opt_data.theta_init([1,3:2:end]) = model_data.theta([1,3:2:end]);
opt_data.N_total = 2;  % Total no. of batches
opt_data.input_1_interval = 2; opt_data.input_2_interval = 2; % ineterval of input for coarse search 
opt_data.c_k = 0.02;     opt_data.a_k = 0.05; % step sizes in local search


count = 1;
for u1 = opt_data.input_bounds(1,1):opt_data.input_1_interval/4:opt_data.input_bounds(1,2)
    for u2 = opt_data.input_bounds(2,1):opt_data.input_2_interval/4:opt_data.input_bounds(2,2)
        u = [u1;u2];
        mediumMat_qbound(:,count) = medium;
        mediumMat_qbound(opt_data.Index_input_1,count) = u1;
         mediumMat_qbound(opt_data.Index_input_2,count) = u2;
         count = count + 1;
        j = j + 1
    end 
    j = 1;
    i = i + 1;
end
[cExt_sequence_qbound, qExt_sequence_qbound] = DataGeneration2(mediumMat_qbound, model_data.Amac, model_data.theta, model_data.Xv, model_data.F, 0, 0, 0, 0);
 
obj = (model_data.F*ones(1,size(qExt_sequence_qbound,2)) - qExt_sequence_qbound(22,:)).*qExt_sequence_qbound(23,:);
obj_matrix = reshape(obj,[17,17])'; 
constraint_2_matrix = reshape(qExt_sequence_qbound(22,:),[17,17])';
constraint_1_matrix = reshape(cExt_sequence_qbound(13,:),[17,17])';

opt_data.qbound(1:22,2) = 2*ones(22,1);
opt_data.qbound(1:22,1) = -2*ones(22,1);
opt_data.qbound(22,2) = 2000*ones(1,1);
opt_data.qbound(22,1) = 0*ones(1,1);
opt_data.qbound( 23,2) =2000*ones(1,1);
opt_data.qbound( 23,1) =  0*ones(1,1);


%% Gaussian noise STD definition
noise_std_test = 0.05*(mean(abs(qExt_sequence_qbound)'));

%% Generate initial experiment data

mediumMat_init = repmat(medium,1,opt_data.noConditions);

for i = 1 : opt_data.noConditions
    mediumMat_init([1:10,12:18,20:end],i) = mediumMat_init([1:10,12:18,20:end],i);
    mediumMat_init(11,i) = (1 - 2*rand())+mediumMat_init(11,i); % +- 60% of base medium
    mediumMat_init(19,i) = (1 - 2*rand())+mediumMat_init(19,i); % +- 60% of base medium 
    if mediumMat_init(11,i) < opt_data.input_bounds(1,1) 
        mediumMat_init(11,i) = max(mediumMat_init(11,i),opt_data.input_bounds(1,1));
    end
    if mediumMat_init(11,i) > opt_data.input_bounds(1,2)
        mediumMat_init(11,i) = min(mediumMat_init(11,i),opt_data.input_bounds(1,2));
    end
    if mediumMat_init(19,i) < opt_data.input_bounds(2,1)
        mediumMat_init(19,i) = max(mediumMat_init(19,i),opt_data.input_bounds(2,1));
    end
    if mediumMat_init(19,i) > opt_data.input_bounds(2,2)
        mediumMat_init(19,i) = min(mediumMat_init(19,i),opt_data.input_bounds(2,2));
    end
end
[cExt_sequence, qExt_sequence] = DataGenerationGauss(mediumMat_init, model_data.Amac, model_data.theta, model_data.Xv, model_data.F, opt_data.percErrXv, opt_data.percErrMedium, opt_data.percErrConc, opt_data.percErrRates,noise_std_test');


%%
[thetaVecReal,nzp,~,activationPars,macroIndexVector] = ConstructParameterVectorFromMatrix(model_data.theta);
thetaVecInit = thetaVecReal;
opt_data_temp = opt_data;
opt_data_temp.Index_input_1 = 11;
opt_data_temp.Index_input_2 = 19;
opt_data_temp.input_bounds = [medium(11),medium(11); ...
                         medium(19),medium(19)];
[score,Index_selected_para,length_selected_para,norm_S] = rank_parameters_explicit(thetaVecReal, [], activationPars, nzp, model_data.Amac, opt_data_temp.rate_of_interest,model_data.V,model_data.Xv,model_data.F, [], [], opt_data_temp, medium);

%% mean gaussian std
[S,I] = sort(score,'descend');  

selectedParametersIndexes = I(1:10);
Index_selected_para = selectedParametersIndexes;
length_selected_para = length(selectedParametersIndexes);
thetaVecInit = thetaVecReal;
thetaVecInit(selectedParametersIndexes) = thetaVecInit(selectedParametersIndexes);
thetaMatrix0 = ConstructParameterMatrixFromVector(thetaVecInit, nzp, activationPars);

W = diag(1./max(abs(qExt_sequence)'));
[id_model.thetaMatrix, id_model.totalCovarianceMatrix,id_model.covMatrix_reduced, selectedParametersIndexes] = ModelUpdateSubsetGaussian(thetaMatrix0, qExt_sequence, cExt_sequence, model_data.Amac, selectedParametersIndexes, diag((1./noise_std_test)));

[id_model.thetaVector, id_model.nzp, ~, model_data.activationPars,macroIndexVector] = ConstructParameterVectorFromMatrix(id_model.thetaMatrix);

%%
worst_obj_matrix = []; best_obj_matrix = []; fval_constraint_violation_1_matrix = []; fval_constraint_violation_2_matrix = [];
exitflag_worst_matrix = []; exitflag_exitflag_best = []; exitflag_constraint_1_matrix = [];  exitflag_constraint_2_matrix = [];
worst_x_value= {};best_x_value= {};
u_exlored_coarse_search = []; f_explored_ub_coarse_search = []; f_explored_lb_coarse_search = [];
i = 1; j = 1; % i: u1; j: u2
%%
tic
for u1 = opt_data.input_bounds(1,1):opt_data.input_1_interval:opt_data.input_bounds(1,2)
    for u2 = opt_data.input_bounds(2,1):opt_data.input_2_interval:opt_data.input_bounds(2,2)
        u = [u1;u2];
        [worst_x_value{i,j},worst_obj_matrix(i,j),exitflag_worst_matrix(i,j)] = obtain_worst_case_obj_functionWG(u,id_model,  model_data, opt_data, Index_selected_para,length_selected_para,medium);
        [best_x_value{i,j},best_obj_matrix(i,j),exitflag_best_matrix(i,j)] = obtain_best_case_obj_functionWG(u,id_model, model_data, opt_data, Index_selected_para,length_selected_para,medium);
        [~,fval_constraint_violation_1_matrix(i,j),exitflag_constraint_1_matrix(i,j)] = obtain_obj_for_constraint_violation_1WG(u,id_model, model_data, opt_data, Index_selected_para,length_selected_para,medium);
        [~,fval_constraint_violation_2_matrix(i,j),exitflag_constraint_2_matrix(i,j)] = obtain_obj_for_constraint_violation_2WG(u,id_model, model_data, opt_data, Index_selected_para,length_selected_para,medium);
        if (fval_constraint_violation_1_matrix(i,j) > 0 && fval_constraint_violation_2_matrix(i,j) > 0)
            u_exlored_coarse_search = [u_exlored_coarse_search,u];
            f_explored_ub_coarse_search = [f_explored_ub_coarse_search,best_obj_matrix(i,j)];
            f_explored_lb_coarse_search = [f_explored_lb_coarse_search,worst_obj_matrix(i,j)];
        end
        
        j = j + 1
    end
    j = 1;
    i = i + 1
end
toc

%% Select starting point for local search
worst_obj_vec = reshape(worst_obj_matrix.',1,[]);
exitflag_worst_vec = reshape(exitflag_worst_matrix.',1,[]);
best_obj_vec = reshape(best_obj_matrix.',1,[]);
exitflag_best_vec = reshape(exitflag_best_matrix.',1,[]);
fval_constraint_violation_1_vec = reshape(fval_constraint_violation_1_matrix.',1,[]);
fval_constraint_violation_1_vec = sum(fval_constraint_violation_1_vec>0,1);
exitflag_constraint_1_vec = reshape(exitflag_constraint_1_matrix.',1,[]);
fval_constraint_violation_2_vec = reshape(fval_constraint_violation_2_matrix.',1,[]);
fval_constraint_violation_2_vec = sum(fval_constraint_violation_2_vec>0,1);
exitflag_constraint_2_vec = reshape(exitflag_constraint_2_matrix.',1,[]);

[~, index_init_point] = sort(worst_obj_vec .* fval_constraint_violation_1_vec .* fval_constraint_violation_2_vec, 'descend');
initial_point_index = index_init_point(1:3); % select 4 initial points which are with the 4 largest worst-case function values
index_matrix = reshape((1: length(opt_data.input_bounds(1,1):opt_data.input_1_interval:opt_data.input_bounds(1,2))* length(opt_data.input_bounds(2,1):opt_data.input_2_interval:opt_data.input_bounds(2,2))),length(opt_data.input_bounds(1,1):opt_data.input_1_interval:opt_data.input_bounds(1,2)),[])';
index_row_vec = []; index_col_vec = []; initial_inputs = [];
for i = 1 : 2
    [index_row_vec, index_col_vec] = find(index_matrix == initial_point_index(i));
    u_1 = (index_row_vec  - 1)*opt_data.input_2_interval + opt_data.input_bounds(2,1); u_2 = (index_col_vec - 1)*opt_data.input_1_interval + opt_data.input_bounds(1,1);
    initial_inputs(:,i) = [u_1; u_2]; % ininital inputs for local search which is determined by coarse search
end

%% Start optimization loops
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Define parameters for optimization
m = 2; % input dimension
% Experiment design parameters
exp_design_stop_epsilon = 0.001; 
N_exp_design = 5; 
sigma_exp_design = 1; 
opt_data.theta_bounds = [zeros(length_selected_para,1), inf(length_selected_para,1)];

% Storage vectors
robust_optimum_hist = []; % Can be made more efficient with pre-allocation
best_worst_case_hist= [];
thetahat_hist = [];
% Delta_p_bound_hist = [];
covariance_matrix_hist = [];

worst_obj_matrix_hist = [];
best_obj_matrix_hist = [];
exitflag_best_matrix_hist = [];
exitflag_worst_matrix_hist = [];
fval_constraint_violation_1_matrix_hist = [];
exitflag_constraint_1_matrix_hist = [];
fval_constraint_violation_2_matrix_hist = [];
exitflag_constraint_2_matrix_hist = [];
acquisition_function_max_hist = [];
u_max_acquisition_hist = [];
best_obj_robust_optimum_input_hist = [];

no_steps = 20;
u_hist_all_batches = cell(opt_data.N_total+1,1);
f_worst_case_all_batches = cell(opt_data.N_total+1,1);
%%
for k = 1 : opt_data.N_total
    % Robust Optimization Step
    [best_obj_robust_optimum_input,robust_optimum_input, best_worst_case, u_hist, f_explored_lb, f_explored_ub, u_explored,constraint_violation_direction_hist,u_hist_matrix, worst_case_vec] = RunRobustOptimization(initial_inputs, no_steps, id_model, opt_data, model_data,Index_selected_para,length_selected_para,medium,u_exlored_coarse_search,f_explored_ub_coarse_search,f_explored_lb_coarse_search);
    u_hist_all_batches{k} = u_hist;
    f_worst_case_all_batches{k} = worst_case_vec;
    
    % Maximize Acquisition Function Step
    [u_max_acquisition, acquisition_function_max] = MaximizeAcquisitionFunction(best_worst_case, f_explored_ub, f_explored_lb, u_explored,u_exlored_coarse_search,f_explored_ub_coarse_search,f_explored_lb_coarse_search);
    
    % Optimally design experiments based on acquisition function
    u_new_sequence = OptimallyDesignedExperiments(exp_design_stop_epsilon, N_exp_design, sigma_exp_design, u_max_acquisition, acquisition_function_max, robust_optimum_input, opt_data.input_bounds);
    
    % Run Experiments 
    if ~isempty(u_new_sequence)
        mediumMat_new_sequence = repmat(medium,1,length(u_new_sequence));

        for i = 1 : length(u_new_sequence)
            mediumMat_new_sequence([1:10,12:18,20:end],i) = mediumMat_new_sequence([1:10,12:18,20:end],i); 
            mediumMat_new_sequence(11,i) = u_new_sequence(1,i);
            mediumMat_new_sequence(19,i) = u_new_sequence(2,i); 
        end
        [cExt_new, qExt_new, distVec_new] = DataGenerationGauss(mediumMat_new_sequence, model_data.Amac, model_data.theta, model_data.Xv, model_data.F, opt_data.percErrXv, opt_data.percErrMedium, opt_data.percErrConc, opt_data.percErrRates, noise_std_test');

        cExt_sequence=[cExt_sequence,cExt_new];
        qExt_sequence=[qExt_sequence,qExt_new];
    end
    
    if isempty(u_new_sequence)
        break
    end
    % Uses previously identified parameters as starting point for the new identification
    thetahat_hist = [thetahat_hist id_model.thetaMatrix]; 
    covariance_matrix_hist = [covariance_matrix_hist, id_model.covMatrix_reduced];
    thetaMatrix0 = ConstructParameterMatrixFromVector(thetaVecInit, nzp, activationPars);
    W = diag(1./max(abs(qExt_sequence)'));
    [id_model.thetaMatrix, id_model.totalCovarianceMatrix,id_model.covMatrix_reduced, selectedParametersIndexes] = ModelUpdateSubsetGaussian(thetaMatrix0, qExt_sequence, cExt_sequence, model_data.Amac, selectedParametersIndexes, diag(1./noise_std_test));      
    [id_model.thetaVector, id_model.nzp, ~, model_data.activationPars,macroIndexVector] = ConstructParameterVectorFromMatrix(id_model.thetaMatrix);
    
    % Updates robust optimums so far with relative best worst cases
    best_obj_robust_optimum_input_hist = [best_obj_robust_optimum_input_hist, best_obj_robust_optimum_input];
    robust_optimum_hist = [robust_optimum_hist, robust_optimum_input];
    best_worst_case_hist = [best_worst_case_hist;best_worst_case];
    worst_obj_matrix_hist = [worst_obj_matrix_hist;worst_obj_matrix];
    best_obj_matrix_hist = [best_obj_matrix_hist;best_obj_matrix];
    exitflag_best_matrix_hist = [exitflag_best_matrix_hist;exitflag_best_matrix];
    exitflag_worst_matrix_hist = [exitflag_worst_matrix_hist;exitflag_worst_matrix];
    fval_constraint_violation_1_matrix_hist = [fval_constraint_violation_1_matrix_hist;fval_constraint_violation_1_matrix];
    exitflag_constraint_1_matrix_hist = [exitflag_constraint_1_matrix_hist;exitflag_constraint_1_matrix];
    fval_constraint_violation_2_matrix_hist = [fval_constraint_violation_2_matrix_hist;fval_constraint_violation_2_matrix];
    exitflag_constraint_2_matrix_hist = [exitflag_constraint_2_matrix_hist;exitflag_constraint_2_matrix];
    
    u_max_acquisition_hist = [u_max_acquisition_hist;u_max_acquisition]; acquisition_function_max_hist = [acquisition_function_max_hist;acquisition_function_max];
%    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Coarse search
    worst_obj_matrix = []; best_obj_matrix = []; fval_constraint_violation_1_matrix = []; fval_constraint_violation_2_matrix = [];
    exitflag_worst_matrix = []; exitflag_exitflag_best = []; exitflag_constraint_1_matrix = [];  exitflag_constraint_2_matrix = [];
    u_exlored_coarse_search = []; f_explored_ub_coarse_search = []; f_explored_lb_coarse_search = [];
    i = 1; j = 1; % i: u1; j: u2
    for u1 = opt_data.input_bounds(1,1):opt_data.input_1_interval:opt_data.input_bounds(1,2)
        for u2 = opt_data.input_bounds(2,1):opt_data.input_2_interval:opt_data.input_bounds(2,2)
            u = [u1;u2];
            [worst_x_value{i,j},worst_obj_matrix(i,j),exitflag_worst_matrix(i,j)] = obtain_worst_case_obj_functionWG(u,id_model,  model_data, opt_data, Index_selected_para,length_selected_para,medium);
            [best_x_value{i,j},best_obj_matrix(i,j),exitflag_best_matrix(i,j)] = obtain_best_case_obj_functionWG(u,id_model, model_data, opt_data, Index_selected_para,length_selected_para,medium);
            [~,fval_constraint_violation_1_matrix(i,j),exitflag_constraint_1_matrix(i,j)] = obtain_obj_for_constraint_violation_1WG(u,id_model, model_data, opt_data, Index_selected_para,length_selected_para,medium);
            [~,fval_constraint_violation_2_matrix(i,j),exitflag_constraint_2_matrix(i,j)] = obtain_obj_for_constraint_violation_2WG(u,id_model, model_data, opt_data, Index_selected_para,length_selected_para,medium);            
            if (fval_constraint_violation_1_matrix(i,j) > 0 && fval_constraint_violation_2_matrix(i,j) > 0)
                u_exlored_coarse_search = [u_exlored_coarse_search,u];
                f_explored_ub_coarse_search = [f_explored_ub_coarse_search,best_obj_matrix(i,j)];
                f_explored_lb_coarse_search = [f_explored_lb_coarse_search,worst_obj_matrix(i,j)];
            end            
            j = j + 1
        end
        j = 1;
        i = i + 1
    end
    % Select starting point for local search
    worst_obj_vec = reshape(worst_obj_matrix.',1,[]);
    exitflag_worst_vec = reshape(exitflag_worst_matrix.',1,[]);
    best_obj_vec = reshape(best_obj_matrix.',1,[]);
    exitflag_best_vec = reshape(exitflag_best_matrix.',1,[]);
    fval_constraint_violation_1_vec = reshape(fval_constraint_violation_1_matrix.',1,[]);
    fval_constraint_violation_1_vec = sum(fval_constraint_violation_1_vec>0,1);
    exitflag_constraint_1_vec = reshape(exitflag_constraint_1_matrix.',1,[]);
    fval_constraint_violation_2_vec = reshape(fval_constraint_violation_2_matrix.',1,[]);
    fval_constraint_violation_2_vec = sum(fval_constraint_violation_2_vec>0,1);
    exitflag_constraint_2_vec = reshape(exitflag_constraint_2_matrix.',1,[]);
    
    [~, index_init_point] = sort(worst_obj_vec .* fval_constraint_violation_1_vec .* fval_constraint_violation_2_vec, 'descend');
    initial_point_index = index_init_point(1:4); % select 4 initial points which are with the 4 largest worst-case function values
    index_matrix = reshape((1: length(opt_data.input_bounds(1,1):opt_data.input_1_interval:opt_data.input_bounds(1,2))* length(opt_data.input_bounds(2,1):opt_data.input_2_interval:opt_data.input_bounds(2,2))),length(opt_data.input_bounds(1,1):opt_data.input_1_interval:opt_data.input_bounds(1,2)),[])';
    index_row_vec = []; index_col_vec = [];
    initial_inputs = [];
    for i = 1 : 2
        [index_row_vec, index_col_vec] = find(index_matrix == initial_point_index(i));
        u_1 = (index_row_vec  - 1)*opt_data.input_2_interval + opt_data.input_bounds(2,1); u_2 = (index_col_vec - 1)*opt_data.input_1_interval + opt_data.input_bounds(1,1);
        initial_inputs(:,i) = [u_1; u_2]; % ininital inputs for local search which is determined by coarse search
    end
end
%
thetahat_hist = [thetahat_hist, id_model.thetaMatrix];
covariance_matrix_hist = [covariance_matrix_hist, id_model.covMatrix_reduced];


%% Result after the final batch of experiments
[best_obj_robust_optimum_input,robust_optimum_input, best_worst_case, u_hist, f_explored_lb, f_explored_ub, u_explored,constraint_violation_direction_hist,u_hist_matrix, worst_case_vec] = RunRobustOptimization(initial_inputs, no_steps, id_model, opt_data, model_data,Index_selected_para,length_selected_para,medium,u_exlored_coarse_search,f_explored_ub_coarse_search,f_explored_lb_coarse_search);
u_hist_all_batches{k} = u_hist;
f_worst_case_all_batches{k} = worst_case_vec;

% Maximize Acquisition Function Step
[u_max_acquisition, acquisition_function_max] = MaximizeAcquisitionFunction(best_worst_case, f_explored_ub, f_explored_lb, u_explored,u_exlored_coarse_search,f_explored_ub_coarse_search,f_explored_lb_coarse_search);

% Optimally design experiments based on acquisition function
u_new_sequence = OptimallyDesignedExperiments(exp_design_stop_epsilon, N_exp_design, sigma_exp_design, u_max_acquisition, acquisition_function_max, robust_optimum_input, opt_data.input_bounds);
best_obj_robust_optimum_input_hist = [best_obj_robust_optimum_input_hist,best_obj_robust_optimum_input];
robust_optimum_hist = [robust_optimum_hist, robust_optimum_input];
best_worst_case_hist = [best_worst_case_hist;best_worst_case];
worst_obj_matrix_hist = [worst_obj_matrix_hist;worst_obj_matrix];
best_obj_matrix_hist = [best_obj_matrix_hist;best_obj_matrix];
exitflag_best_matrix_hist = [exitflag_best_matrix_hist;exitflag_best_matrix];
exitflag_worst_matrix_hist = [exitflag_worst_matrix_hist;exitflag_worst_matrix];
fval_constraint_violation_1_matrix_hist = [fval_constraint_violation_1_matrix_hist;fval_constraint_violation_1_matrix];
exitflag_constraint_1_matrix_hist = [exitflag_constraint_1_matrix_hist;exitflag_constraint_1_matrix];
fval_constraint_violation_2_matrix_hist = [fval_constraint_violation_2_matrix_hist;fval_constraint_violation_2_matrix];
exitflag_constraint_2_matrix_hist = [exitflag_constraint_2_matrix_hist;exitflag_constraint_2_matrix];
u_max_acquisition_hist = [u_max_acquisition_hist;u_max_acquisition]; acquisition_function_max_hist = [acquisition_function_max_hist;acquisition_function_max];