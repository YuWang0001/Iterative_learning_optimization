function [x_value,worst_obj,exitflag] = obtain_obj_for_constraint_violation_1WG(u,id_model, model_data, opt_data, Index_selected_para,length_selected_para,medium)
    medium_nominal = medium;
    medium_nominal(opt_data.Index_input_1) = u(1);
    medium_nominal(opt_data.Index_input_2) = u(2);
    [cExtNom, qExtNom,~, ~] = RunSingleExperiment2(medium_nominal, model_data.Amac,id_model.thetaMatrix, model_data.Xv, model_data.F, 0, 0, 0, 0,medium(1:end-2));

    Objective_worst_case = @(x)(Define_obj_for_constraint_violation_1WG(x,u,id_model,  model_data, opt_data, Index_selected_para,length_selected_para, medium_nominal,cExtNom(1:end-2)));
    nonlcons_for_evaluation = @(x)(constriants_for_constraint_violationWG(x,u,id_model,  model_data, opt_data, Index_selected_para,length_selected_para,opt_data.alpha,medium,qExtNom,cExtNom(1:end-2)));
   
    options = optimoptions('fmincon','Display','none','Algorithm','interior-point','MaxIterations',300,'MaxFunctionEvaluations',300,'StepTolerance',1e-5,...
        'SubproblemAlgorithm','cg','OptimalityTolerance',5*1e-4,'SpecifyObjectiveGradient',true,'SpecifyConstraintGradient',true,'ConstraintTolerance',1e-6,...
        'HessianApproximation','bfgs','CheckGradients',false);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [x_value,fval,exitflag,~] = fmincon(Objective_worst_case,[cExtNom',zeros(1,length_selected_para)],[],[],[],[],[],[],nonlcons_for_evaluation,options);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    worst_obj = value(fval);
end
