load result.mat
id_model_plot.covMatrix_reduced = covariance_matrix_hist(1:10,1:10); 
id_model_plot.thetaMatrix = thetahat_hist(:,1:47);
id_model_plot.totalCovarianceMatrix  = zeros(227,227);
[id_model_plot.thetaVector, id_model_plot.nzp, ~, model_data.activationPars,macroIndexVector_plot] = ConstructParameterVectorFromMatrix(id_model_plot.thetaMatrix);
[~,worst_obj_plot_init,exitflag_worst_plot] = obtain_worst_case_obj_functionWG([8,2],id_model_plot,  model_data, opt_data, Index_selected_para,length_selected_para,medium);
[~,best_obj_plot_init,exitflag_best_plot] = obtain_best_case_obj_functionWG([8,2],id_model_plot, model_data, opt_data, Index_selected_para,length_selected_para,medium);
%%
figure(10)
hold on
grid on

ylabel('Harvested mAb rates (pmol/(cell $\cdot$ day)', 'interpreter','latex','FontSize',12);
u_axis = [1;2;3;4];

mediumMat_plot_0 = medium;
mediumMat_plot_0(opt_data.Index_input_1) = 1;
mediumMat_plot_0(opt_data.Index_input_2) = 7.8;
[cExt_sequence_plot_0, qExt_sequence_plot_0] = DataGeneration2(mediumMat_plot_0, model_data.Amac, model_data.theta, model_data.Xv, model_data.F, 0, 0, 0, 0);
obj_plot_0 = model_data.Xv*(model_data.F*ones(1,size(qExt_sequence_plot_0,2)) - qExt_sequence_plot_0(22,:)).*qExt_sequence_plot_0(23,:);

plot(u_axis(1:end),[obj_plot_0;obj_plot_0;obj_plot_0;obj_plot_0]*10.81,'LineWidth',2,'Color','[0 0.4470 0.7410]', 'MarkerEdgeColor','[0 0.4470 0.7410]','MarkerFaceColor','[0 0.4470 0.7410]')
plot(u_axis(1:end),[worst_obj_plot_init;best_worst_case_hist(1);best_worst_case_hist(2);best_worst_case_hist(3)]*model_data.Xv*10.81,'--o','LineWidth',2,'Color','[0.6350 0.0780 0.1840]','MarkerEdgeColor','[0.6350 0.0780 0.1840]','MarkerFaceColor','[0.6350 0.0780 0.1840]')
plot(u_axis(2:end),[best_obj_robust_optimum_input_hist(1);best_obj_robust_optimum_input_hist(2);best_obj_robust_optimum_input_hist(3)]*model_data.Xv*10.81,'--o','LineWidth',2,'Color','[0.8500 0.3250 0.0980]','MarkerEdgeColor','[0.8500 0.3250 0.0980]','MarkerFaceColor','[0.8500 0.3250 0.0980]')

mediumMat_plot_init = medium;
[cExt_sequence_plot_init, qExt_sequence_plot_init] = DataGeneration2(mediumMat_plot_init, model_data.Amac, model_data.theta, model_data.Xv, model_data.F, 0, 0, 0, 0);
obj_plot_init = model_data.Xv*(model_data.F*ones(1,size(qExt_sequence_plot_init,2)) - qExt_sequence_plot_init(22,:)).*qExt_sequence_plot_init(23,:);

mediumMat_plot_1 = medium;
mediumMat_plot_1(opt_data.Index_input_1) = robust_optimum_hist(1,1);
mediumMat_plot_1(opt_data.Index_input_2) = robust_optimum_hist(2,1);
[cExt_sequence_plot_1, qExt_sequence_plot_1] = DataGeneration2(mediumMat_plot_1, model_data.Amac, model_data.theta, model_data.Xv, model_data.F, 0, 0, 0, 0);
obj_plot_1 = model_data.Xv*(model_data.F*ones(1,size(qExt_sequence_plot_1,2)) - qExt_sequence_plot_1(22,:)).*qExt_sequence_plot_1(23,:);

mediumMat_plot_2 = medium;
mediumMat_plot_2(opt_data.Index_input_1) = robust_optimum_hist(1,2);
mediumMat_plot_2(opt_data.Index_input_2) = robust_optimum_hist(2,2);
[cExt_sequence_plot_2, qExt_sequence_plot_2] = DataGeneration2(mediumMat_plot_2, model_data.Amac, model_data.theta, model_data.Xv, model_data.F, 0, 0, 0, 0);
obj_plot_2 = model_data.Xv*(model_data.F*ones(1,size(qExt_sequence_plot_2,2)) - qExt_sequence_plot_2(22,:)).*qExt_sequence_plot_2(23,:);

mediumMat_plot_3 = medium;
mediumMat_plot_3(opt_data.Index_input_1) = robust_optimum_hist(1,3);
mediumMat_plot_3(opt_data.Index_input_2) = robust_optimum_hist(2,3);
[cExt_sequence_plot_3, qExt_sequence_plot_3] = DataGeneration2(mediumMat_plot_3, model_data.Amac, model_data.theta, model_data.Xv, model_data.F, 0, 0, 0, 0);
obj_plot_3 = model_data.Xv*(model_data.F*ones(1,size(qExt_sequence_plot_3,2)) - qExt_sequence_plot_3(22,:)).*qExt_sequence_plot_3(23,:);

plot(u_axis,[obj_plot_init;obj_plot_1;obj_plot_2;obj_plot_3]*10.81,'--diamond','LineWidth',2,'Color','[0.4660 0.6740 0.1880]', 'MarkerEdgeColor','[0.4660 0.6740 0.1880]','MarkerFaceColor','[0.4660 0.6740 0.1880]')
names = {'Base Medium';'Robust Opt. 0'; 'Robust Opt.1'; 'Robust Opt. 2';};
set(gca, 'XTick', 1:4, 'XTickLabel', names,'FontSize',12);
ylim([2,8])
legend({'true value of true optimum','worst-case value under uncertainty', 'best-case value under uncertainty','true value of the medium'},'FontSize',12,'interpreter','latex')

hold off

%%
figure(11)
count = 1;
for u1 = opt_data.input_bounds(1,1):opt_data.input_1_interval/10:opt_data.input_bounds(1,2)
    for u2 = opt_data.input_bounds(2,1):opt_data.input_2_interval/10:opt_data.input_bounds(2,2)
        u = [u1;u2];
        mediumMat_plot(:,count) = medium;
        mediumMat_plot(opt_data.Index_input_1,count) = u1;
         mediumMat_plot(opt_data.Index_input_2,count) = u2;
         count = count + 1;
        j = j + 1
    end 
    j = 1;
    i = i + 1;
end

[cExt_sequence_plot, qExt_sequence_plot] = DataGeneration2(mediumMat_plot, model_data.Amac, model_data.theta, model_data.Xv, model_data.F, 0, 0, 0, 0);
 
obj_plot = (model_data.F*ones(1,size(qExt_sequence_plot,2)) - qExt_sequence_plot(22,:)).*qExt_sequence_plot(23,:);
%%
figure(11)
obj_matrix_plot = reshape(obj_plot,[size(opt_data.input_bounds(1,1):opt_data.input_1_interval/10:opt_data.input_bounds(1,2),2),size(opt_data.input_bounds(2,1):opt_data.input_2_interval/10:opt_data.input_bounds(2,2),2)])'; 
constraint_2_matrix_plot = reshape(qExt_sequence_plot(22,:),[size(opt_data.input_bounds(1,1):opt_data.input_1_interval/10:opt_data.input_bounds(1,2),2),size(opt_data.input_bounds(2,1):opt_data.input_2_interval/10:opt_data.input_bounds(2,2),2)])';
constraint_1_matrix_plot = reshape(cExt_sequence_plot(13,:),[size(opt_data.input_bounds(1,1):opt_data.input_1_interval/10:opt_data.input_bounds(1,2),2),size(opt_data.input_bounds(2,1):opt_data.input_2_interval/10:opt_data.input_bounds(2,2),2)])';

constraint_1_matrix_plot_bin = constraint_1_matrix_plot - opt_data.constraint_bounds(1);
constraint_2_matrix_plot_bin = constraint_2_matrix_plot - opt_data.constraint_bounds(2);

constraint_1_matrix_plot_bin(constraint_1_matrix_plot_bin > 0) = NaN;
constraint_2_matrix_plot_bin(constraint_2_matrix_plot_bin > 0) = NaN;

constraint_1_matrix_plot_bin(constraint_1_matrix_plot_bin < 0) = 1;
constraint_2_matrix_plot_bin(constraint_2_matrix_plot_bin < 0) = 1;
u1 = opt_data.input_bounds(1,1):opt_data.input_1_interval/10:opt_data.input_bounds(1,2);
u2 = opt_data.input_bounds(2,1):opt_data.input_2_interval/10:opt_data.input_bounds(2,2);
pcolor(u1,u2,model_data.Xv*obj_matrix_plot.*constraint_1_matrix_plot_bin.*constraint_2_matrix_plot_bin*10.81);colorbar;
ylabel('[{Asn}$_{in}$]','interpreter','latex','FontSize',14)
xlabel('[{Gln}$_{in}$]','interpreter','latex','FontSize',14)

hold on 
plot(robust_optimum_hist(2,end),robust_optimum_hist(1,end),'ro', 'MarkerSize',2,'MarkerFaceColor', 'r')
% hold off 
hold on
plot([ 2 robust_optimum_hist(2,1:end)],[8 robust_optimum_hist(1,1:end)],'r-','LineWidth',1.5)
hold on
u_max_acquisition_hist_plot = [u_max_acquisition_hist(1) u_max_acquisition_hist(3) u_max_acquisition_hist(5); u_max_acquisition_hist(2) u_max_acquisition_hist(4) u_max_acquisition_hist(6)];
plot([ u_max_acquisition_hist_plot(2,1:end)],[u_max_acquisition_hist_plot(1,1:end)],'diamond','LineWidth',2.5,'MarkerEdgeColor','[1 .6 .6]','MarkerFaceColor',[1 .6 .6])
hold on
plot([7.8],[1],'bpentagram','MarkerSize',10,'MarkerFaceColor', 'b')
hold on
plot([2],[8],'blacksquare','MarkerSize',10,'MarkerFaceColor', 'black')
hold on
plot([robust_optimum_hist(2,end)],[robust_optimum_hist(1,end)],'pentagram','MarkerSize',10,'MarkerEdgeColor','[0.4660 0.6740 0.1880]','MarkerFaceColor',[0.4660 0.6740 0.1880])
hold on
plot([robust_optimum_hist(2,1:end-1)],[robust_optimum_hist(1,1:end-1)],'black*','MarkerSize',6,'MarkerFaceColor', 'black')
hold off

%%

figure(12)
mean_diff_with_robust_opt_plot_1 = -(best_worst_case_hist(1) - (best_obj_matrix_hist(1:5,:)+worst_obj_matrix_hist(1:5,:))/2);
var_plot_1 = (best_obj_matrix_hist(1:5,:)-worst_obj_matrix_hist(1:5,:));

fval_constraint_violation_1_matrix_hist_plot_1 = fval_constraint_violation_1_matrix_hist(1:5,:);
fval_constraint_violation_2_matrix_hist_plot_1 = fval_constraint_violation_2_matrix_hist(1:5,:);

fval_constraint_violation_1_matrix_hist_plot_1(fval_constraint_violation_1_matrix_hist_plot_1 < 0) = NaN;
fval_constraint_violation_2_matrix_hist_plot_1(fval_constraint_violation_2_matrix_hist_plot_1 < 0) = NaN;

fval_constraint_violation_1_matrix_hist_plot_1(fval_constraint_violation_1_matrix_hist_plot_1 > 0)= 1;
fval_constraint_violation_2_matrix_hist_plot_1(fval_constraint_violation_2_matrix_hist_plot_1 > 0) = 1;

u1_plot = opt_data.input_bounds(1,1):opt_data.input_1_interval:opt_data.input_bounds(1,2);
u2_plot  = opt_data.input_bounds(2,1):opt_data.input_2_interval:opt_data.input_bounds(2,2);

data_1 = model_data.Xv.*model_data.Xv.*mean_diff_with_robust_opt_plot_1.* var_plot_1*10.81^2;
data_1 = max(0, data_1).*fval_constraint_violation_1_matrix_hist_plot_1.*fval_constraint_violation_2_matrix_hist_plot_1;
data_1 = data_1(end:-1:1,:);
imagesc(data_1, 'AlphaData', ~isnan(data_1))

% Set tick labels on x-axis and y-axis
xticks([ 1    2 3 4  5])
xticklabels({'1', '3', '5', '7', '9'})
yticks([ 1    2 3 4  5])
yticklabels({ '9', '7','5','3','1'})

colormap parula
colorbar

% Set axis labels and title
xlabel('[{Gln}$_{in}$]','interpreter','latex','FontSize',16)
ylabel('[{Asn}$_{in}$]','interpreter','latex','FontSize',16)
title('(a) With Initial Experiments','interpreter','latex','FontSize',16)

figure(13)
mean_diff_with_robust_opt_plot_2 = -(best_worst_case_hist(2) - (best_obj_matrix_hist(6:10,:)+worst_obj_matrix_hist(6:10,:))/2);
var_plot_2 = (best_obj_matrix_hist(6:10,:)-worst_obj_matrix_hist(6:10,:));

fval_constraint_violation_1_matrix_hist_plot_2 = fval_constraint_violation_1_matrix_hist(6:10,:);
fval_constraint_violation_2_matrix_hist_plot_2 = fval_constraint_violation_2_matrix_hist(6:10,:);

fval_constraint_violation_1_matrix_hist_plot_2(fval_constraint_violation_1_matrix_hist_plot_2 < 0) = NaN;
fval_constraint_violation_2_matrix_hist_plot_2(fval_constraint_violation_2_matrix_hist_plot_2 < 0) = NaN;

fval_constraint_violation_1_matrix_hist_plot_2(fval_constraint_violation_1_matrix_hist_plot_2 > 0)= 1;
fval_constraint_violation_2_matrix_hist_plot_2(fval_constraint_violation_2_matrix_hist_plot_2 > 0) = 1;

u1_plot = opt_data.input_bounds(1,1):opt_data.input_1_interval:opt_data.input_bounds(1,2);
u2_plot  = opt_data.input_bounds(2,1):opt_data.input_2_interval:opt_data.input_bounds(2,2);

data_2 = model_data.Xv.*model_data.Xv.*mean_diff_with_robust_opt_plot_2.* var_plot_2*10.81^2;
data_2 = max(0,data_2).*fval_constraint_violation_1_matrix_hist_plot_2.*fval_constraint_violation_2_matrix_hist_plot_2;
data_2 = data_2(end:-1:1,:);
imagesc(data_2, 'AlphaData', ~isnan(data_2))

% Set tick labels on x-axis and y-axis
xticks([ 1    2 3 4  5])
xticklabels({'1', '3', '5', '7', '9'})
yticks([ 1    2 3 4  5])
yticklabels({ '9', '7','5','3','1'})

colormap parula
colorbar

% Set axis labels and title
xlabel('[{Gln}$_{in}$]','interpreter','latex','FontSize',16)
ylabel('[{Asn}$_{in}$]','interpreter','latex','FontSize',16)
title('(b) After Batch 1 Experiments','interpreter','latex','FontSize',16)


figure(14)
mean_diff_with_robust_opt_plot_3 = -(best_worst_case_hist(3) - (best_obj_matrix_hist(11:15,:)+worst_obj_matrix_hist(11:15,:))/2);
var_plot_3 = (best_obj_matrix_hist(11:15,:)-worst_obj_matrix_hist(11:15,:));

fval_constraint_violation_1_matrix_hist_plot_3 = fval_constraint_violation_1_matrix_hist(11:15,:);
fval_constraint_violation_2_matrix_hist_plot_3 = fval_constraint_violation_2_matrix_hist(11:15,:);

fval_constraint_violation_1_matrix_hist_plot_3(fval_constraint_violation_1_matrix_hist_plot_3 < 0) = NaN;
fval_constraint_violation_2_matrix_hist_plot_3(fval_constraint_violation_2_matrix_hist_plot_3 < 0) = NaN;

fval_constraint_violation_1_matrix_hist_plot_3(fval_constraint_violation_1_matrix_hist_plot_3 > 0)= 1;
fval_constraint_violation_2_matrix_hist_plot_3(fval_constraint_violation_2_matrix_hist_plot_3 > 0) = 1;

u1_plot = opt_data.input_bounds(1,1):opt_data.input_1_interval:opt_data.input_bounds(1,2);
u2_plot  = opt_data.input_bounds(2,1):opt_data.input_2_interval:opt_data.input_bounds(2,2);

% Plot heatmap using imagesc
data_3 = model_data.Xv.*model_data.Xv.*mean_diff_with_robust_opt_plot_3.* var_plot_3*10.81^2;
data_3 = max(0,data_3).*fval_constraint_violation_1_matrix_hist_plot_3.*fval_constraint_violation_2_matrix_hist_plot_3;
data_3 = data_3(end:-1:1,:);
imagesc(data_3, 'AlphaData', ~isnan(data_3))

% Set tick labels on x-axis and y-axis
xticks([ 1    2 3 4  5])
xticklabels({'1', '3', '5', '7', '9'})
yticks([ 1    2 3 4  5])
yticklabels({ '9', '7','5','3','1'})

colormap parula
colorbar

% Set axis labels and title
xlabel('[{Gln}$_{in}$]','interpreter','latex','FontSize',16)
ylabel('[{Asn}$_{in}$]','interpreter','latex','FontSize',16)
title('(c) After Batch 2 Experiments','interpreter','latex','FontSize',16)