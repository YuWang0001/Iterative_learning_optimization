%% Jacobian of macrorates vector with respect to parameters

function JthW = JacobianThetaW(cExt, parameterMatrix, realNZP)

    if nargin < 3
        [paraVec, nonZeroParametersMap, wMaxAndInhibition, ~, ~] = ConstructParameterVectorFromMatrix(parameterMatrix);
    else
        [paraVec, nonZeroParametersMap, wMaxAndInhibition, ~, ~] = ConstructParameterVectorFromMatrix(parameterMatrix, realNZP);
    end
    noMacroRates = size(parameterMatrix,1);
    JthW = zeros(noMacroRates, length(paraVec));
    iterSensVec = 1;
    for i = 1 : noMacroRates %for macrorate w_i

%         for j = 1 : size(wMaxAndInhibition, 1) % only maximal rates and inhibition
            for l = 1 : size(wMaxAndInhibition, 2)
                if nonZeroParametersMap(i,l) ~= 0
                    if l == 1 % maximal rate sensitivity
                        yji = GetYJIForMaximalRate(1, cExt, parameterMatrix(i,:));
                        JthW(i,iterSensVec) = yji;
                        iterSensVec = iterSensVec + 1;
                    else % inhibition coeff. sensitivity
                        m = l-1; %index of the concentration of interest
                        yji = GetYJIForInhCoeff(1, cExt, parameterMatrix(i,:),m);
                        cm = cExt(m); % conc. to which the coeff. refers to
                        JthW(i,iterSensVec) = -yji*(cm/(parameterMatrix(i,2*m+1)*cm + 1)^2);
                        iterSensVec = iterSensVec + 1;
                    end
                end
            end
%         end
    end
end

function yji = GetYJIForMaximalRate(AmacElemIJ, cExt, parameterMatrixRowJ)
    yji = AmacElemIJ;
    for k = 1 : length(cExt)
        yji = yji*hdc(cExt(k),parameterMatrixRowJ(2*k),parameterMatrixRowJ(2*k+1));
    end
end

function yji = GetYJIForInhCoeff(AmacElemIJ, cExt, parameterMatrixRowJ, m)
    yji = AmacElemIJ*parameterMatrixRowJ(1);
    for k = 1 : length(cExt)
        if k ~= m
            yji = yji*hdc(cExt(k),parameterMatrixRowJ(2*k),parameterMatrixRowJ(2*k+1));
        else
            yji = yji*hdc(cExt(m),parameterMatrixRowJ(2*m),0);
        end
    end
end