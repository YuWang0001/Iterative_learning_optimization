% Function to rank parameters based on orthognalization method 
function [score,Index_selected_para,length_selected_para,norm_S] = rank_parameters_explicit(thetaVector0, cExt, activationPars, nzp, Amac, rate_of_interest,V,Xv,F,covMatrix,macroIndexVector,opt_data,medium)
    thetaMatrix = ConstructParameterMatrixFromVector(thetaVector0, nzp, activationPars);
    S = zeros(length(rate_of_interest),length(thetaVector0));
    wb = waitbar(0,'Evaluating sensitivities for different inputs...');
    iterCount = 1;
    for  u_1 = opt_data.input_bounds(1,1):opt_data.input_1_interval:opt_data.input_bounds(1,2)
        for u_2 = opt_data.input_bounds(2,1):opt_data.input_2_interval:opt_data.input_bounds(2,2)
            waitbar(iterCount/100,wb,'Evaluating sensitivities for different inputs...');
            medium(opt_data.Index_input_1) = u_1;
            medium(opt_data.Index_input_2) = u_2;
            [cExt,~,~,~] = RunSingleExperiment2(medium,Amac,thetaMatrix,Xv,F,0,0,0,0,medium(1:end-2)); % solves nominal mbe
            for i = 1 : length(rate_of_interest)
                S(i,:) = S(i,:) + abs(calculate_local_sensitivity_explicit(thetaVector0, cExt, activationPars, nzp, Amac, rate_of_interest(i),V,Xv,F,medium));
            end
            iterCount = iterCount + 1;
        end
    end
    close(wb);
    u_1 = opt_data.input_bounds(1,1):opt_data.input_1_interval:opt_data.input_bounds(1,2); u_2 = opt_data.input_bounds(2,1):opt_data.input_2_interval:opt_data.input_bounds(2,2);
    S = S/(length(u_1)*length(u_2));
    if size(S,1) == 1
        norm_S = abs(S);
    else
        norm_S = vecnorm(S);
    end

    norm_S = norm_S.*(norm_S>1e-4);
    score = norm_S/max(norm_S);
    score = score/max(score);
    Index_selected_para = find(score >  0.1);
    length_selected_para =  length(Index_selected_para);
end
