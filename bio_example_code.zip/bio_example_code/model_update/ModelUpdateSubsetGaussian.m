%% Model Update Module -- assume measurement model with Gaussian noise

function [thetaMatrix, totalCovarianceMatrix, reducedCovarianceMatrix, selectedParametersIndexes] = ModelUpdateSubsetGaussian(thetaMatrix0, qExt, cExt, Amac, selectedParametersIndexes, scalingMatrix)
    [thetaVector0, nzp, ~, activationPars,~] = ConstructParameterVectorFromMatrix(thetaMatrix0);
    [thetaEstVec, reducedCovarianceMatrix] = EstimateThetaParameterVector(thetaVector0, qExt, cExt, Amac, nzp, activationPars, selectedParametersIndexes, scalingMatrix);
    thetaVecWhole = thetaVector0;
    thetaVecWhole(selectedParametersIndexes) = thetaEstVec;
    thetaMatrix = ConstructParameterMatrixFromVector(thetaVecWhole, nzp, activationPars);
    totalCovarianceMatrix = zeros(length(thetaVector0));
    totalCovarianceMatrix(selectedParametersIndexes, selectedParametersIndexes) = reducedCovarianceMatrix;
end


function [thetaEst, covMatrix] = EstimateThetaParameterVector(thetaVector0, qExt, cExt, Amac, nzp, activationPars, selectedParametersIndexes, scalingMatrix)
    qExtVector = [];
    for i = 1 : size(qExt,2)
        qExtVector = [qExtVector;
                      scalingMatrix*qExt(:,i)];
    end
    options = optimoptions('lsqcurvefit','Display','iter','PlotFcn','optimplotresnorm','SpecifyObjectiveGradient',true,'CheckGradient',true,'FiniteDifferenceType','central');
    theta0VectorWhole = thetaVector0;
    thetaVector0 = thetaVector0(selectedParametersIndexes);
    lowerBoundParamVector = zeros(length(thetaVector0),1);
    upperBoundParamVector = 1000*ones(length(thetaVector0),1);    
    [thetaEst,resnorm,~,~,~,~,J1] = lsqcurvefit(@(th,c)(RatesModelForFit(th,c,Amac,nzp,activationPars,selectedParametersIndexes,theta0VectorWhole,scalingMatrix)),thetaVector0,cExt,qExtVector,lowerBoundParamVector,upperBoundParamVector, options);
    J2 = EvaluateJacobianOfEstimate(thetaEst, cExt, Amac, nzp, activationPars, selectedParametersIndexes, theta0VectorWhole, scalingMatrix);
    covMatrix = inv(J2'*J2+eye(size(J2,2))*1e-5)*(resnorm/size(qExt,2));
end

function J = EvaluateJacobianOfEstimate(thetaVec, cExt, Amac, nzp, activationPars, selectedParametersIndexes, theta0VectorWhole, scalingMatrix)
    noConditions = size(cExt,2);
    thetaVecWhole = theta0VectorWhole;
    thetaVecWhole(selectedParametersIndexes) = thetaVec;
    J = [];
    thetaMat = ConstructParameterMatrixFromVector(thetaVecWhole, nzp, activationPars);
    for i = 1 : noConditions
        JwSubset = JacobianThetaWEff(cExt(:,i),thetaMat);
        JwSubset = JwSubset(:,selectedParametersIndexes);
        J =[J;
                   scalingMatrix*Amac*JwSubset];            
    end
end

function [qMod, JthQMod] = RatesModelForFit(thetaVec, cExt, Amac, nzp, activationPars, selectedParametersIndexes, theta0VectorWhole,scalingMatrix)
    noConditions = size(cExt,2);
    qMod = [];
    JthQMod = [];
    thetaVecWhole = theta0VectorWhole;
    thetaVecWhole(selectedParametersIndexes) = thetaVec;
    thetaMat = ConstructParameterMatrixFromVector(thetaVecWhole, nzp, activationPars);
    for i = 1 : noConditions
        qi = ComputeQExt(cExt(:,i),thetaMat,Amac);
        JwSubset = JacobianThetaWEff(cExt(:,i),thetaMat);
        JwSubset = JwSubset(:,selectedParametersIndexes);

        qMod = [qMod;
                scalingMatrix*qi];
        JthQMod =[JthQMod;
                  scalingMatrix*Amac*JwSubset];
    end
end