function [thetaVector, nonZeroParametersMap, wMaxAndInhibition, activationPars, macroIndexVector] = ConstructParameterVectorFromMatrix(thetaMatrix, realNZP)
    wMaxAndInhibition = thetaMatrix(:,[1,3:2:end]);
    activationPars = thetaMatrix(:,2:2:end-1);
    if nargin < 2
        nonZeroParametersMap = (wMaxAndInhibition > 0);
    else
        nonZeroParametersMap = realNZP;
    end
    nonZeroParametersNumber = sum(sum(nonZeroParametersMap));
    thetaVector = zeros(nonZeroParametersNumber,1);
    macroIndexVector = zeros(size(thetaVector));
    iterThetaVector = 1;
    for i = 1 : size(wMaxAndInhibition,1)
        for j = 1 : size(wMaxAndInhibition,2)
            if nonZeroParametersMap(i,j) > 0
                thetaVector(iterThetaVector) = wMaxAndInhibition(i,j);
                macroIndexVector(iterThetaVector) = i;
                iterThetaVector = iterThetaVector + 1;
            end
        end
    end
end
