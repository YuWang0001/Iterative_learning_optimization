function obj = MBESquaredNorm(x, u, F, Xv, Amac, theta)
    MBE = Xv*ComputeQExt(x, theta, Amac) - F*x + F*u;
    MBE = [MBE(1:end-2);0;0]; % excludes mAb and biomass from mbe
    obj = norm(MBE,2);
end