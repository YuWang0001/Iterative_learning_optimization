%% Function to define rates
function para_sat_matrix = GenerateSaturationCoeffMatrix(Amac,w_max,kinetic_group,code,para_sat,para_inh,x)
    para_sat_matrix = zeros(132,23);
    for j = 1 : 132
        para_inh_j = para_inh(j,:); code_j = code(j,:); kinetic_group_j = kinetic_group(j,:);
        % code 1a-c
        if code_j == "'1a-c'"
            if (Amac(end,j) > 0) || (Amac(end-1,j) > 0)
                temp = 1;
                ind = find(Amac( :, j) < 0);
                for i = 1: length(ind)
                    if (ind(i) < 10) || (ind(i) == 16) || (ind(i) == 19) % Sat: EAA, Gln, Cys
                        temp = temp * ( x(ind(i))./(para_sat(ind(i))) )/ ( ( x(ind(i))./(para_sat(ind(i))) )+1 );
                        para_sat_matrix(j,ind(i)) = para_sat(ind(i));
                    end
                end
            else
                temp = 1;
                ind = find(Amac( :, j) < 0);
                for i = 1: length(ind)
                    temp = temp * ( x(ind(i))./(para_sat(ind(i))) )/ ( ( x(ind(i))./(para_sat(ind(i))) )+1 );
                    para_sat_matrix(j,ind(i)) = para_sat(ind(i));
                end
            end
        end

        % code 2
        if (code_j == "'2a'") || (code_j == "'2b'")
            temp = 1;
            ind = find(Amac( :, j) < 0);
            for i = 1: length(ind)
                if (ind(i) < 10) || (ind(i) == 16) % Sat: EAA, Cys
                    para_sat_matrix(j,ind(i)) = para_sat(ind(i));
                end
            end
        end

        if (code_j == "'2c'")
            temp = 1;
            ind = find(Amac( :, j) < 0);
            for i = 1: length(ind)
                if (ind(i) < 10) || (ind(i) == 16) || (ind(i) == 19) % Sat: EAA, Gln, Cys;
                    para_sat_matrix(j,ind(i)) = para_sat(ind(i));
                end
            end
            if  kinetic_group_j == 46
                temp = temp * 1 ./ ( ( x(16)./(para_inh_j(16)) )+1 ); %Inh: Cys
            end
            if  kinetic_group_j == 47
                temp = temp * 1 ./ ( ( x(10)./(para_inh_j(10)) )+1 ); %Inh: Ser
            end
            if  kinetic_group_j == 48
                temp = temp * 1 ./ ( ( x(19)./(para_inh_j(19)) )+1 ); %Inh: Gln
            end
            if  kinetic_group_j == 49
                temp = temp * 1 ./ ( ( x(21)./(para_inh_j(21)) )+1 ); %Inh: Asp
            end
            if  kinetic_group_j == 50
                temp = temp * 1 ./ ( ( x(11)./(para_inh_j(11)) )+1 ); %Inh: Asn
            end
        end

        if (code_j == "'2d'")
            temp = 1;
            ind = find(Amac( :, j) < 0);
            for i = 1: length(ind)
                if (ind(i) < 10) || (ind(i) == 16) % Sat: EAA, Cys;
                    para_sat_matrix(j,ind(i)) = para_sat(ind(i));
                end
            end
            if  kinetic_group_j == 38
                temp = temp * 1 ./ ( ( x(20)./(para_inh_j(20)) )+1 ); %Inh: Glu
            end
            if  kinetic_group_j == 39
                temp = temp * 1 ./ ( ( x(15)./(para_inh_j(15)) )+1 ); %Inh: Gly
            end
            if  kinetic_group_j == 40
                temp = temp * 1 ./ ( ( x(21)./(para_inh_j(21)) )+1 ); %Inh: Asp
            end
            if  kinetic_group_j == 41
                temp = temp * 1 ./ ( ( x(19)./(para_inh_j(19)) )+1 ); %Inh: Gln
            end
        end

        if (code_j == "'2e'")
            temp = 1;
            ind = find(Amac( :, j) < 0);
            for i = 1: length(ind)
                if (ind(i) < 10) || (ind(i) == 16) || (ind(i) == 19) % Sat: EAA, Gln, Cys;
                    para_sat_matrix(j,ind(i)) = para_sat(ind(i));
                end
            end
            if  kinetic_group_j == 51
                temp = temp * ( x(10)./(para_sat(10)) )./ ( ( x(10)./(para_sat(10)) )+1 ); %Sat: Ser
                para_sat_matrix(j,10) = para_sat(10);
            end
            if  kinetic_group_j == 52
                temp = temp * ( x(19)./(para_sat(19)) )./ ( ( x(19)./(para_sat(19)) )+1 ); %Sat: Gln
                para_sat_matrix(j,19) = para_sat(19);
            end
            if  kinetic_group_j == 53
                temp = temp * ( x(21)./(para_sat(21)) )./ ( ( x(21)./(para_sat(21)) )+1 ); %Sat: Asp
                para_sat_matrix(j,21) = para_sat(21);
            end
            if  kinetic_group_j == 54
                temp = temp * ( x(11)./(para_sat(11)) )./ ( ( x(11)./(para_sat(11)) )+1 ); %Sat: Asn
                para_sat_matrix(j,11) = para_sat(11);
            end
        end

        if (code_j == "'2f'")
            temp = 1;
            ind = find(Amac( :, j) < 0);
            for i = 1: length(ind)
                if (ind(i) < 10) || (ind(i) == 16)  % Sar: EAA, Cys;
                    temp = temp * ( x(ind(i))./(para_sat(ind(i))) )/ ( ( x(ind(i))./(para_sat(ind(i))) )+1 );
                    para_sat_matrix(j,ind(i)) = para_sat(ind(i));
                end
            end
            if  kinetic_group_j == 42
                temp = temp * ( x(20)./(para_sat(20)) )./ ( ( x(20)./(para_sat(20)) )+1 ); %Sat: Glu
                para_sat_matrix(j,20) = para_sat(20);
            end
            if  kinetic_group_j == 43
                temp = temp * ( x(15)./(para_sat(15)) )./ ( ( x(15)./(para_sat(15)) )+1 ); %Sat: Gly
                para_sat_matrix(j,15) = para_sat(15);
            end
            if  kinetic_group_j == 44
                temp = temp * ( x(21)./(para_sat(21)) )./ ( ( x(21)./(para_sat(21)) )+1 ); %Sat: Asp
                para_sat_matrix(j,21) = para_sat(21);
            end
            if  kinetic_group_j == 45
                temp = temp * ( x(19)./(para_sat(19)) )./ ( ( x(19)./(para_sat(19)) )+1 ); %Sat: Gln
                para_sat_matrix(j,19) = para_sat(19);
            end
        end

        % code 3
        if (code_j == "'3a'")
            temp = 1;
            ind = find(Amac( :, j) < 0);
            for i = 1: length(ind)
                temp = temp * ( x(ind(i))./(para_sat(ind(i))) )/ ( ( x(ind(i))./(para_sat(ind(i))) )+1 );
                para_sat_matrix(j,ind(i)) = para_sat(ind(i));
            end
            if  kinetic_group_j == 4
                temp = temp * 1 ./ ( ( x(17)./(para_inh_j(17)) )+1 ); %Inh: Ala
            end
            if  kinetic_group_j == 5
                temp = temp * 1 ./ ( ( x(11)./(para_inh_j(11)) )+1 ); %Inh: Asn
            end
            if  kinetic_group_j == 6
                temp = temp * 1 ./ ( ( x(21)./(para_inh_j(21)) )+1 ); %Inh: Asp
            end
            if  kinetic_group_j == 7
                temp = temp * 1 ./ ( ( x(19)./(para_inh_j(19)) )+1 ); %Inh: Gln
            end
            if  kinetic_group_j == 8
                temp = temp * 1 ./ ( ( x(20)./(para_inh_j(20)) )+1 ); %Inh: Glu
            end
            if  kinetic_group_j == 9
                temp = temp * 1 ./ ( ( x(15)./(para_inh_j(15)) )+1 ); %Inh: Gly
            end
            if  kinetic_group_j == 10
                temp = temp * 1 ./ ( ( x(10)./(para_inh_j(10)) )+1 ); %Inh: Ser
            end
        end

        if (code_j == "'3b'")
            temp = 1;
            ind = find(Amac( :, j) < 0);
            for i = 1: length(ind)
                temp = temp * ( x(ind(i))./(para_sat(ind(i))) )/ ( ( x(ind(i))./(para_sat(ind(i))) )+1 );
                para_sat_matrix(j,ind(i)) = para_sat(ind(i));
            end
            if  kinetic_group_j == 11
                temp = temp * 1 ./ ( ( x(19)./(para_inh_j(19)) )+1 ); %Inh: Gln
            end
            if  kinetic_group_j == 24
                temp = temp * 1 ./ ( ( x(11)./(para_inh_j(11)) )+1 ); %Inh: Asn
            end
            if  kinetic_group_j == 34
                temp = temp * 1 ./ ( ( x(16)./(para_inh_j(16)) )+1 ); %Inh: Cys
            end
            if  kinetic_group_j == 35
                if para_inh_j(16) == 0
                    temp = temp * ( x(16)./(para_sat(16)) )./ ( ( x(16)./(para_sat(16)) )+1 ); %Sar: Cys
                    para_sat_matrix(j,16) = para_sat(16);
                else
                    temp = temp * 1 ./ ( ( x(16)./(para_inh_j(16)) )+1 ); %Inh: Cys
                end
            end
            if  kinetic_group_j == 36
                temp = temp * 1 ./ ( ( x(11)./(para_inh_j(11)) )+1 ); %Inh: Asn
            end
        end

        % code 4
        if (code_j == "'4a'")
            temp = 1;
            ind = find(Amac( :, j) < 0);
            if kinetic_group_j == 28
                for i = 1: length(ind)
                    if ind(i) ~= 20
                        temp = temp * ( x(ind(i))./(para_sat(ind(i))) )/ ( ( x(ind(i))./(para_sat(ind(i))) )+1 ); % No sat Glu
                        para_sat_matrix(j,ind(i)) = para_sat(ind(i));
                    end
                end
            end
            if kinetic_group_j == 29
                for i = 1: length(ind)
                    if ind(i) ~= 15
                        temp = temp * ( x(ind(i))./(para_sat(ind(i))) )/ ( ( x(ind(i))./(para_sat(ind(i))) )+1 ); % No sat Gly
                        para_sat_matrix(j,ind(i)) = para_sat(ind(i));
                    end
                end
            end
            if kinetic_group_j == 30
                for i = 1: length(ind)
                    if ind(i) ~= 16
                        temp = temp * ( x(ind(i))./(para_sat(ind(i))) )/ ( ( x(ind(i))./(para_sat(ind(i))) )+1 ); % No sat Cys
                        para_sat_matrix(j,ind(i)) = para_sat(ind(i));
                    end
                end
            end
            if kinetic_group_j == 31
                for i = 1: length(ind)
                    if ind(i) ~= 17
                        temp = temp * ( x(ind(i))./(para_sat(ind(i))) )/ ( ( x(ind(i))./(para_sat(ind(i))) )+1 ); % No sat Ala
                        para_sat_matrix(j,ind(i)) = para_sat(ind(i));
                    end
                end
            end
            if kinetic_group_j == 33
                for i = 1: length(ind)
                    if ind(i) ~= 21
                        temp = temp * ( x(ind(i))./(para_sat(ind(i))) )/ ( ( x(ind(i))./(para_sat(ind(i))) )+1 ); % No sat Asp
                        para_sat_matrix(j,ind(i)) = para_sat(ind(i));
                    end
                end
            end
        end

        if (code_j == "'4b'")
            temp = 1;
            ind = find(Amac( :, j) < 0);
            for i = 1: length(ind)
                temp = temp * ( x(ind(i))./(para_sat(ind(i))) )/ ( ( x(ind(i))./(para_sat(ind(i))) )+1 );
                para_sat_matrix(j,ind(i)) = para_sat(ind(i));
            end
            if kinetic_group_j == 26
                temp = temp * ( x(19)./(para_sat(19)) )./ ( ( x(19)./(para_sat(19)) )+1 ); %Sat: Gln
                para_sat_matrix(j,19) = para_sat(19);
            end
            if kinetic_group_j == 27
                temp = temp * ( x(11)./(para_sat(11)) )./ ( ( x(11)./(para_sat(11)) )+1 ); %Sat: Asn
                para_sat_matrix(j,11) = para_sat(11);
            end
            if kinetic_group_j == 32
                temp = temp * ( x(10)./(para_sat(10)) )./ ( ( x(10)./(para_sat(10)) )+1 ); %Sat: Ser
                para_sat_matrix(j,10) = para_sat(10);
            end
        end

        if (code_j == "'4c'")
            temp = 1;
            ind = find(Amac( :, j) < 0);
            for i = 1: length(ind)
                temp = temp * ( x(ind(i))./(para_sat(ind(i))) )/ ( ( x(ind(i))./(para_sat(ind(i))) )+1 );
                para_sat_matrix(j,ind(i)) = para_sat(ind(i));
            end
            if kinetic_group_j == 12
                temp = temp * 1 ./ ( ( x(19)./(para_inh_j(19)) )+1 ); %Inh: Gln
            end
            if kinetic_group_j == 13
                temp = temp * 1 ./ ( ( x(19)./(para_inh_j(19)) )+1 ); %Inh: Gln
            end
            if kinetic_group_j == 14
                temp = temp * 1 ./ ( ( x(19)./(para_inh_j(19)) )+1 ); %Inh: Gln
            end
            if kinetic_group_j == 15
                temp = temp * 1 ./ ( ( x(19)./(para_inh_j(19)) )+1 ); %Inh: Gln
            end
            if kinetic_group_j == 16
                temp = temp * 1 ./ ( ( x(19)./(para_inh_j(19)) )+1 ); %Inh: Gln
            end
            if kinetic_group_j == 17
                temp = temp * 1 ./ ( ( x(19)./(para_inh_j(19)) )+1 ); %Inh: Gln
            end
            if kinetic_group_j == 18
                temp = temp * 1 ./ ( ( x(19)./(para_inh_j(19)) )+1 ); %Inh: Gln
            end
            if kinetic_group_j == 19
                temp = temp * 1 ./ ( ( x(19)./(para_inh_j(19)) )+1 ); %Inh: Gln
            end
            if kinetic_group_j == 20
                temp = temp * 1 ./ ( ( x(19)./(para_inh_j(19)) )+1 ); %Inh: Gln
            end
            if kinetic_group_j == 21
                temp = temp * 1 ./ ( ( x(19)./(para_inh_j(19)) )+1 ); %Inh: Gln
            end
            if kinetic_group_j == 22
                temp = temp * 1 ./ ( ( x(10)./(para_inh_j(10)) )+1 ); %Inh: Ser
            end
            if kinetic_group_j == 23
                temp = temp * 1 ./ ( ( x(19)./(para_inh_j(19)) )+1 ); %Inh: Gln
            end
            if kinetic_group_j == 60
                temp = temp * 1 ./ ( ( x(20)./(para_inh_j(20)) )+1 ); %Inh: Glu
            end
        end

        % code 5
        if (code_j == "'5'")
            temp = 1;
            ind = find(Amac( :, j) < 0);
            for i = 1: length(ind)
                if ind(i) ~= 11
                    temp = temp * ( x(ind(i))./(para_sat(ind(i))) )/ ( ( x(ind(i))./(para_sat(ind(i))) )+1 );
                    para_sat_matrix(j,ind(i)) = para_sat(ind(i));
                end
            end
            if kinetic_group_j == 37
                temp = temp * 1 ./ ( ( x(11)./(para_inh_j(11)) )+1 ); %Inh: Asn
            end
        end

        % code 6
        if (code_j == "'6a'")
            temp = 1;
            ind = find(Amac( :, j) < 0);
            for i = 1: length(ind)
                temp = temp * ( x(ind(i))./(para_sat(ind(i))) )/ ( ( x(ind(i))./(para_sat(ind(i))) )+1 );
                para_sat_matrix(j,ind(i)) = para_sat(ind(i));
                if (kinetic_group_j == 55) && (para_sat(ind(i)) ~= 0)
                    temp = temp * 1 ./ ( ( x(ind(i))./(para_inh_j(ind(i))) )+1 ); %Inh: Asn
                end
            end
        end

        if (code_j == "'6b'")
            temp = 1;
            ind = find(Amac( :, j) < 0);
            for i = 1: length(ind)
                temp = temp * ( x(ind(i))./(para_sat(ind(i))) )/ ( ( x(ind(i))./(para_sat(ind(i))) )+1 );
                para_sat_matrix(j,ind(i)) = para_sat(ind(i));
            end
            if kinetic_group_j == 56
                temp = temp * 1 ./ ( ( x(19)./(para_inh_j(19)) )+1 ); %Inh: Gln
            end
            if kinetic_group_j == 57
                temp = temp * 1 ./ ( ( x(16)./(para_inh_j(16)) )+1 ); %Inh: Cys
            end
            if kinetic_group_j == 58
                temp = temp * 1 ./ ( ( x(10)./(para_inh_j(10)) )+1 ); %Inh: Ser
            end
            if kinetic_group_j == 59
                temp = temp * 1 ./ ( ( x(15)./(para_inh_j(15)) )+1 ); %Inh: Gly
            end
        end

        % code 7
        if code_j == "'7'"
            temp = 1;
            if kinetic_group_j == 25
                temp = temp * 1 ./ ( ( x(19)./(para_inh_j(19)) )+1 ); %Inh: Gln
            end
        end
        % times maximal rate
        w(j,:) = w_max(j,:)*temp;
    end
    q = Amac * w;
end