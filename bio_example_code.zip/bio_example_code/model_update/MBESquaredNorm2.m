function [obj, gradobj] = MBESquaredNorm2(x, u, F, Xv, Amac, theta)
    q = ComputeQExt([x;0;0],theta,Amac);
    q = q(1:end-2);
    u = u(1:end-2);
    MBE = Xv*q - F*x + F*u;
    obj = MBE'*MBE;
    Jw = MacroKineticsJacobian(theta,[x;0;0]);
    gradobj = 2*(Xv*Amac(1:(end-2),:)*Jw(:,1:(end-2))-F*eye(length(x)))'*MBE;
end