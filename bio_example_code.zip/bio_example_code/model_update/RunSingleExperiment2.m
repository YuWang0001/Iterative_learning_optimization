function [c, q, dist, w] = RunSingleExperiment2(u, Amac, theta, Xv, F, percErrXv, percErrMedium, percErrConc, percErrRates, cInit)
    options = optimoptions('fmincon','Display','iter-detailed','Algorithm','interior-point','MaxIterations',1000,'MaxFunctionEvaluations',5000,'SpecifyObjectiveGradient',true,'StepTolerance',1e-14);
    optionsLsqNonlin = optimoptions('lsqnonlin','SpecifyObjectiveGradient',true,'Display','off','StepTolerance',1e-10,'OptimalityTolerance',1e-6); % maybe comment out optimality tolerance, add ,'Diagnostics','on' if needed
    c0 = u(1:end-2);
    c0 = cInit;
    distOnXv = (2*percErrXv*rand() - percErrXv)*Xv; % percentage error on Xv
    Xv = Xv + distOnXv;
    distOnMedium = (2*percErrMedium*rand(size(u)) - percErrMedium).*u; % percentage error on medium
    u = u + distOnMedium;
    c = lsqnonlin(@(x)MBErika(x,u,F,Xv,Amac,theta),c0,zeros(21,1),[],optionsLsqNonlin);
    c = [c;0;0];
    distOnConc = (2*percErrConc*rand(size(c)) - percErrConc).*c; % percentage error on concentration
    c = c + distOnConc;
    [q,w] = ComputeQExt(c,theta,Amac);
    distOnRates = (2*percErrRates*rand(size(q)) - percErrRates).*q; % percentage error on concentration
    q = q + distOnRates;
    dist.distOnXv = distOnXv;
    dist.distOnMedium = distOnMedium;
    dist.distOnConc = distOnConc;
    dist.distOnRates = distOnRates;
end

function [obj, gradobj] = MBErika(x,u,F,Xv,Amac,theta)
    q = ComputeQExt([x;0;0],theta,Amac);
    q = q(1:end-2);
    u = u(1:end-2);
    obj = (Xv*q - F*x + F*u);
    Jw = MacroKineticsJacobianOld(theta,[x;0;0]);
    gradobj = (Xv*Amac(1:(end-2),:)*Jw(:,1:(end-2))-F*eye(length(x)));
    2*(Xv*Amac(1:(end-2),:)*Jw(:,1:(end-2))-F*eye(length(x)))'*obj;
end