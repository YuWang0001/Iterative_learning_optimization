%% Data generation with Hagrot et al. 2019 model
%
%   NOTE:   This function allow a uniformly distributed percentage noise on
%           viable cell density, medium implementation, extracellular
%           metabolite concentrations and extracellular metabolite rates.
%           This function IS NOT used in simulating the experimental
%           conditions (see instead DataGenerationGauss for which normally
%           distributed noise is assumed).
%
%   output : 
%       -   cExtMat   : matrix with i-th column being the residual concentrations of 
%                       the i-th experiment
%       -   qExtMat   : matrix with i-th column being the uptake-secretion rates of
%                       the i-th experiment
%       -   distArray : cell array, with i-th entry containing information
%                       on realization of the disturbances
%       -   wMat      : matrix with i-th column being the vector of
%                       macroreaction rates of the i-th experiment
%
%   inputs :
%       -   medium    : matrix with i-th column being the feed medium
%                       concentrations of the i-the experiment
%       -   Amac      : macroreaction stoichiometric matrix
%       -   theta     : parameter matrix
%       -   Xv        : viable cell-density times bioreactor volume
%       -   F         : perfusion rate
%       -   percErrXv : percentage error (noise) on the viable cell density
%                       (this is set to zero to generate nominal conditions)
%       -   percErrMedium : percentage error (noise) on the medium
%                           implementation (this is set to zero to generate
%                           nominal conditions)
%       -   percErrConc : percentage error (noise) on the extracellular
%                         metabolite concentrations (this is set to zero 
%                         to generate nominal conditions)
%       -   percErrRates : percentage error (noise) on the extracellular
%                         metabolite rates (this is set to zero 
%                         to generate nominal conditions)


function [cExtMat, qExtMat, distArray, wMat] = DataGeneration2(medium, Amac, theta, Xv, F, percErrXv, percErrMedium, percErrConc, percErrRates)
    noConditions = size(medium,2);
    cExtMat = zeros(23,noConditions);
    qExtMat = zeros(23,noConditions);
    distArray = cell(1,noConditions);
    wMat = zeros(size(Amac,2),noConditions);
    wb = waitbar(0,'Running Experiments...');
    for i = 1 : size(medium,2)
        waitbar(i/size(medium,2),wb,'Running experiments...');
        u = medium(:,i);
        [cExtMat(:,i), qExtMat(:,i), distArray{i}, wMat(:,i)] = RunSingleExperiment2(u, Amac, theta, Xv, F, percErrXv, percErrMedium, percErrConc, percErrRates, u(1:end-2));
    end
    close(wb);
end


