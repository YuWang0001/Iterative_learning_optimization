%% Data generation with Hagrot et al. 2019 model (GAUSSIAN NOISE)
%
%   output : 
%       -   cExtMat   : matrix with i-th column being the residual concentrations of 
%                       the i-th experiment
%       -   qExtMat   : matrix with i-th column being the uptake-secretion rates of
%                       the i-th experiment
%       -   distArray : cell array, with i-th entry containing information
%                       on realization of the disturbances
%       -   wMat      : matrix with i-th column being the vector of
%                       macroreaction rates of the i-th experiment
%
%   inputs :
%       -   medium    : matrix with i-th column being the feed medium
%                       concentrations of the i-the experiment
%       -   Amac      : macroreaction stoichiometric matrix
%       -   theta     : parameter matrix
%       -   Xv        : viable cell-density times bioreactor volume
%       -   F         : perfusion rate
%       -   percErrXv : percentage error (noise) on the viable cell density
%                       (this is set to zero to generate nominal conditions)
%       -   percErrMedium : percentage error (noise) on the medium
%                           implementation (this is set to zero to generate
%                           nominal conditions)
%       -   percErrConc : percentage error (noise) on the extracellular
%                         metabolite concentrations (this is set to zero 
%                         to generate nominal conditions)
%       -   percErrRates : percentage error (noise) on the extracellular
%                         metabolite rates (this is set to zero 
%                         to generate nominal conditions)
%       -   ratesStdVector : vector containing the square roots of the
%                            diagonal elements for the Gaussian noise
%                            covariance matrix

function [cExtMat, qExtMat, distArray, wMat] = DataGenerationGauss(medium, Amac, theta, Xv, F, percErrXv, percErrMedium, percErrConc, percErrRates, ratesStdVector)
    noConditions = size(medium,2);
    cExtMat = zeros(23,noConditions);
    qExtMat = zeros(23,noConditions);
    distArray = cell(1,noConditions);
    wMat = zeros(size(Amac,2),noConditions);
    for i = 1 : size(medium,2)
        u = medium(:,i);
        [cExtMat(:,i), qExtMat(:,i), distArray{i}, wMat(:,i)] = RunSingleExperiment2(u, Amac, theta, Xv, F, 0, 0, 0, 0, u(1:end-2));
        qExtMat(:,i) = qExtMat(:,i) + randn(23,1).*ratesStdVector;
    end
end


