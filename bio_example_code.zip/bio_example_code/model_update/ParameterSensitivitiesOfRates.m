function dqdth = ParameterSensitivitiesOfRates(Amac, cExt, parameterMatrix)
    [paraVec, nonZeroParametersMap, wMaxAndInhibition, ~, ~] = ConstructParameterVectorFromMatrix(parameterMatrix);
    dqdth = zeros(size(Amac,1), length(paraVec));
    % the element i,j of this matrix is the rate w_i, where the corresponding
    % theta(i,j) is not considered. With j = 1 we mean the maximal rate.   
    wMacroMinusJ = BuildWMacroMinusJ(cExt, parameterMatrix);                                                            

    JthetaW = EvaluateSensitivityOfMacrorates(cExt, parameterMatrix, wMacroMinusJ, nonZeroParametersMap, paraVec);
    dqdth = Amac*JthetaW;
end

function JthetaW = EvaluateSensitivityOfMacrorates(cExt, parameterMatrix, wMacroMinusJ, nonZeroParametersMap, paraVec)
    extendedNZP = zeros(size(parameterMatrix));
    extendedNZP(:,1:2:end) = nonZeroParametersMap;
    nPar = length(paraVec);
    JthetaW = zeros(size(parameterMatrix,1),nPar);
    for i = 1 : size(parameterMatrix,1)
        JthetaWi = zeros(size(parameterMatrix));
        for j = 1 : size(JthetaWi,1)
            for k = 1 : size(JthetaWi,2)
                if j == i
                    if k == 1 % maximal rate
                        JthetaWi(j,k) = wMacroMinusJ(j,k);
                    elseif mod(k,2) == 0 % activation parameter 
                        JthetaWi(j,k) = 0;
                    else % inhibition parameter
                        cm = cExt((k-1)/2);
                        if extendedNZP(j,k) ~= 0
                            JthetaWi(j,k) = -wMacroMinusJ(j,k)*(cm/(1+cm*parameterMatrix(j,k))^2);
                        end
                    end
                end
            end
        end
        JthetaWiRow = zeros(1,nPar);
        JthetaWi = JthetaWi(:,1:2:end);
        iterPar = 1;
        for j = 1 : size(JthetaWi,1)
            for k = 1 : size(JthetaWi,2)
                if nonZeroParametersMap(j,k) ~= 0
                    JthetaWiRow(iterPar) = JthetaWi(j,k);
                    iterPar = iterPar + 1;
                end
            end
        end
        JthetaW(i,:) = JthetaWiRow;
    end
end

function dqidth = EvaluateSensitivityForRateI(Amaci, cExt, parameterMatrix, wMacroMinusJ, nonZeroParametersMap)
    dqidthMatrixForm = zeros(size(parameterMatrix));
    for j = 1 : size(parameterMatrix,1)
        for k = 1 : size(parameterMatrix,2)
            if k == 1 % maximal rate
                dqidthMatrixForm(j,k) = Amaci(j)*wMacroMinusJ(j,k);
            elseif mod(k,2) == 0 % activation parameter 
                dqidthMatrixForm(j,k) = 0;
            else % inhibition parameter
                cm = cExt((k-1)/2);
                inhPar = parameterMatrix(j,k);
                if inhPar ~= 0
                    dqidthMatrixForm(j,k) = -Amaci(j)*wMacroMinusJ(j,k)*(cm/(1+cm*inhPar)^2);
                end
            end
        end
    end
    dqidth = [];
    dqidthMatrixForm = dqidthMatrixForm(:,1:2:end); %only selects column relative to maximal rates and inhibition coefficients
    for i = 1 : size(dqidthMatrixForm,1)
        for j = 1 : size(dqidthMatrixForm,2)
            if nonZeroParametersMap(i,j) ~= 0
                dqidth = [dqidth, dqidthMatrixForm(i,j)];
            end
        end
    end
end

function yji = GetYJIForMaximalRate(AmacElemIJ, cExt, parameterMatrixRowJ,j, wMacroMinusJ)
    yji = AmacElemIJ*wMacroMinusJ(j,1);
end

function yji = GetYJIForInhCoeff(AmacElemIJ, cExt, parameterMatrixRowJ, m, j, wMacroMinusJ)
    yji = AmacElemIJ*wMacroMinusJ(j,2*m+1);
end

function wMacroMinusJ = BuildWMacroMinusJ(cExt, parameterMatrix)
    wMatrixComponents = zeros(size(parameterMatrix));
    wMacroMinusJ = ones(size(parameterMatrix));
    for i = 1 : size(wMatrixComponents,1)
        for j = 1 : size(wMatrixComponents,2)
            if j == 1
                wMatrixComponents(i,j) = parameterMatrix(i,j);
            elseif mod(j,2) == 0 % activation parameter
                wMatrixComponents(i,j) = hdc(cExt(j/2),parameterMatrix(i,j),0);
            else %inhibition parameter
                wMatrixComponents(i,j) = hdc(cExt((j-1)/2),0,parameterMatrix(i,j));
            end
        end
    end

    for i = 1 : size(wMacroMinusJ,1)
        for j = 1 : size(wMacroMinusJ,2)
            for k = 1 : j-1
                wMacroMinusJ(i,j) = wMacroMinusJ(i,j)*wMatrixComponents(i,k);
            end
            for k = j+1 : size(wMacroMinusJ,2)
                wMacroMinusJ(i,j) = wMacroMinusJ(i,j)*wMatrixComponents(i,k);
            end
        end
    end

end