function thetaMatrix = ConstructParameterMatrixFromVector(thetaVec, nonZeroParametersMap, activationPars)
    wMaxAndInhibition = zeros(size(nonZeroParametersMap));
    iterThetaVector = 1;
    for i = 1 : size(wMaxAndInhibition,1)
        for j = 1 : size(wMaxAndInhibition,2)
            if nonZeroParametersMap(i,j) > 0
                wMaxAndInhibition(i,j) = thetaVec(iterThetaVector);
                iterThetaVector = iterThetaVector + 1;
            end
        end
    end
    thetaMatrix = zeros(size(nonZeroParametersMap,1),size(nonZeroParametersMap,2)+size(activationPars,2));
    thetaMatrix(:,[1,3:2:end]) = wMaxAndInhibition;
    thetaMatrix(:,2:2:end-1) = activationPars;
end