% Function to calculate local sensitivey of production rate of a metabolite
% with respect to all the parameters

function gradient = calculate_local_sensitivity_explicit(thetaVector0, cExt, activationPars, nzp, Amac, rate_of_interest,V,Xv,F,input)

    tic;

    thetaMatrix = ConstructParameterMatrixFromVector(thetaVector0, nzp, activationPars);
    dfdtheta_eval = Amac*JacobianThetaW(cExt, thetaMatrix);
    dfdtheta = dfdtheta_eval(rate_of_interest,:);

    dfdstate = ConcentrationSensitivityOfRates(Amac, thetaMatrix, cExt);
    dfdstate = dfdstate(rate_of_interest,:);

    dhdtheta = dfdtheta_eval*V*Xv;
    dmbedx = ConcentrationJacobianOfMBE(Amac, thetaMatrix, cExt, F, V, Xv, input);
    dxdtheta = -inv(dmbedx)*dhdtheta;
    toc;

    gradient = dfdstate*dxdtheta + dfdtheta;

end

function dqdstate = ConcentrationSensitivityOfRates(Amac, thetaMatrix, cExt)
    % rates are Amac*w;
    % concentration jacobian of rates is Amac*J_c w
    J_c_w = MacroKineticsJacobianOld(thetaMatrix, cExt);
    dqdstate = Amac*J_c_w; 
end

function dmbedstate  = ConcentrationJacobianOfMBE(Amac, thetaMatrix, cExt, F, V, Xv,input)
    % mbe is Xv*V*Amac*w - F*c + Fu
    % concentration jacobian of mbe is Xv*V*Amac*J_c w - F
    J_c_w = MacroKineticsJacobianOld(thetaMatrix, cExt);
    idMatrix = eye(size(Amac,1));
    F = F*eye(size(Amac,1));
    dmbedstate = Xv*V*Amac*J_c_w - F;
    dmbedstate(22,:) = idMatrix(22,:);
end