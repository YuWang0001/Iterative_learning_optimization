%% Kinetic Jacobian

%  w(y) function is given
%  k_s are given
%  size of y is given

%  Ka and Ki are two matrices
%  Ka(i,j) := activation coefficient for the j-th metabolite on the i-th macroreaction 
%  Ki(i,j) := inhibition coefficient for the j-th metabolite on the i-th macroreaction 
function J = Jacobian_of_kinetic_macro_Old_version_Eff(Ka,Ki,WMAX,r,m,y)
    J = zeros(r,m);
    HDC_matrix = BuildHDCMatrix(Ka,Ki,y);
    for i = 1  : r
        for j = 1 : m
            J_ij = WMAX(i);
            J_ij = J_ij*(partial_kin_yj_wi(Ka(i,j),Ki(i,j),y(j)));
            Ka_minus_j = Ka;
            Ka_minus_j(:,j) = [];
            Ki_minus_j = Ki;
            Ki_minus_j(:,j) = [];
            y_minus_j = y;
            y_minus_j(j) = [];
            J_ij = J_ij*(double_comp_multiplication_minus_yj(HDC_matrix,i,j));
            J(i,j) = J_ij;
        end
    end

end

function HDC_matrix = BuildHDCMatrix(Ka,Ki,y)
    HDC_matrix = zeros(size(Ka));
    for i = 1 : size(Ka,1)
        for j = 1 : size(Ka,2)
            HDC_matrix(i,j) = hdc(y(j),Ka(i,j),Ki(i,j));
        end
    end
end

function dhdj = partial_kin_yj_wi(Ka_i_j,Ki_i_j,y_j)
    if Ka_i_j == 0 && Ki_i_j == 0
        dhdj = 0;
    elseif Ki_i_j == 0 % act
        dhdj = (Ka_i_j)/(y_j + Ka_i_j)^2;
    elseif Ka_i_j == 0 % inh
        dhdj = -(Ki_i_j)/(1+y_j*Ki_i_j)^2;
    else
        dhdj = (Ka_i_j - y_j^2*Ki_i_j)/((y_j+Ka_i_j)^2*(1+y_j*Ki_i_j)^2);
    end
end

function dcmj = double_comp_multiplication_minus_yj(HDC_matrix,i,j)
    dcmj = 1;
    for k = 1 : size(HDC_matrix,2)
        if k ~= j
            factor = HDC_matrix(i,k);
            dcmj = dcmj*factor;
        end
    end
end

