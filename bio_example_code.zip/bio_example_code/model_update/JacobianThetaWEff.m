%% Jacobian of macrorates vector with respect to parameters

function JthW = JacobianThetaWEff(cExt, parameterMatrix, realNZP)

    HDC_matrix = BuildHDCMatrix(parameterMatrix,cExt);

    if nargin < 3
        [paraVec, nonZeroParametersMap, wMaxAndInhibition, ~, ~] = ConstructParameterVectorFromMatrix(parameterMatrix);
    else
        [paraVec, nonZeroParametersMap, wMaxAndInhibition, ~, ~] = ConstructParameterVectorFromMatrix(parameterMatrix, realNZP);
    end
    noMacroRates = size(parameterMatrix,1);
    JthW = zeros(noMacroRates, length(paraVec));
    iterSensVec = 1;
    for i = 1 : noMacroRates %for macrorate w_i
        for l = 1 : size(wMaxAndInhibition, 2)
            if nonZeroParametersMap(i,l) ~= 0
                if l == 1 % maximal rate sensitivity
                    yji = GetYJIForMaximalRate(1, cExt, parameterMatrix(i,:), HDC_matrix(i,:));
                    JthW(i,iterSensVec) = yji;
                    iterSensVec = iterSensVec + 1;
                else % inhibition coeff. sensitivity
                    m = l-1; %index of the concentration of interest
                    yji = GetYJIForInhCoeff(1, cExt, parameterMatrix(i,:),m, HDC_matrix(i,:));
                    cm = cExt(m); % conc. to which the coeff. refers to
                    JthW(i,iterSensVec) = -yji*(cm/(parameterMatrix(i,2*m+1)*cm + 1)^2);
                    iterSensVec = iterSensVec + 1;
                end
            end
        end

    end
end

function HDC_matrix = BuildHDCMatrix(thetaMatrix,y)
    HDC_matrix = zeros(size(thetaMatrix,1),(size(thetaMatrix,2)-1)/2);
    for i = 1 : size(thetaMatrix,1)
        for j = 1 : (size(thetaMatrix,2)-1)/2
            HDC_matrix(i,j) = hdc2(y(j),thetaMatrix(i,2*j),thetaMatrix(i,2*j+1));
        end
    end
end

function yji = GetYJIForMaximalRate(AmacElemIJ, cExt, parameterMatrixRowJ, HDC_matrix_row)
    yji = AmacElemIJ;
    for k = 1 : length(cExt)
        yji = yji*HDC_matrix_row(k);
    end
end

function yji = GetYJIForInhCoeff(AmacElemIJ, cExt, parameterMatrixRowJ, m, HDC_matrix_row)
    yji = AmacElemIJ*parameterMatrixRowJ(1);
    for k = 1 : length(cExt)
        if k ~= m
            yji = yji*HDC_matrix_row(k);
        else
            yji = yji*hdc2(cExt(m),parameterMatrixRowJ(2*m),0);
        end
    end
end