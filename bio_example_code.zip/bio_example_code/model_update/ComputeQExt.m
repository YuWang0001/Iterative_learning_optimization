function [q_mod,w] = ComputeQExt(input,theta,Amac)
    m = (size(theta,2)-1)/2;
    w = zeros(size(Amac,2),1);
    for i = 1 : length(w)
        w(i) = theta(i,1);
        for j = 1 : length(input)
            w(i) = w(i)*hdc(input(j),theta(i,j*2),theta(i,j*2+1));
        end
    end
    q_mod = Amac*w;
end