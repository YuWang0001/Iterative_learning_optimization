function dc = hdc2(x,ka,ki)
    switch ka
        case 0
            switch ki
                case 0
                    dc = 1;
                otherwise
                    dc = (1/(1+x*ki));
            end
        otherwise
            switch ki
                case 0
                    dc = (x/(x+ka));
                otherwise
                    dc = (x/(x+ka))*(1/(1+x*ki));
            end
    end
end
