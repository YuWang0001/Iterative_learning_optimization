function J_w = MacroKineticsJacobianOld(para,y)
    Ka = [];
    Ki = [];
    WM = para(:,1);
    
    for i = 1 : length(y)
        Ka = [Ka,para(:,i*2)];
        Ki = [Ki,para(:,i*2+1)];
    end
    
    r = size(para,1);
    m = length(y);
    J_w = Jacobian_of_kinetic_macro_Old_version(Ka,Ki,WM,r,m,y);
end