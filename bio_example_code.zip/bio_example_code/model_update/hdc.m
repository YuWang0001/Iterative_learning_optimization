function dc = hdc(x,ka,ki)
    if ka == 0 && ki == 0
        dc = 1;
        return;
    elseif ka == 0
        dc = (1/(1+x*ki));
    elseif ki == 0
        dc = (x/(x+ka));
    else
        dc = (x/(x+ka))*(1/(1+x*ki));
    end
end
