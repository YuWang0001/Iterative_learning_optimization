function J_w = MacroKineticsJacobian(para,y)
    Ka = [];
    Ki = [];
    WM = para(:,1);
    
    for i = 1 : length(y)
        Ka = [Ka,para(:,i*2)];
        Ki = [Ki,para(:,i*2+1)];
    end
    
    r = size(para,1);
    m = length(y);
    J_w = Jacobian_of_kinetic_macro(y,para);
end