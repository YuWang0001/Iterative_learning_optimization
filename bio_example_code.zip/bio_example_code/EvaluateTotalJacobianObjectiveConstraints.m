%% Gradients for RO max problems
%   Note: this might need to be adapted to the particular implementation
%
%   The total Jacobian obtained will be
%       totalJacobian = [gradG, gradH1, ..., gradHm, gradF1, ..., gradFp]
%   where gradG is the gradient of the objective function g, gradH1,...,
%   gradHN are the gradients of the equality constraint functions
%   h1,...,hm, while gradF1,..., gradFp are the gradients of the inequality
%   constraint functions f1,...,fp.
%
%   In our case the problem we solve is:
%       max     g(u,x,th)
%       s.t.    hi(u,x,th) = 0, i = {1,...,m}
%               (th-thHat)'*P*(th-thHat) \le rho
%               deltaULb <= (u-uHat) <= deltaUUb
%   with g either being a rate or harvested amount of a metabolite,i.e
%       g(u,x,th) = +-qi(u,x,th) 
%   or 
%       g(u,x,th) = +-Xv/F*(F-mu(u,x,th))*qi(u,x,th)
%   while hi is the i-th mass-balance equation, i.e.
%       h(u,x,th) = Xv*qi - F*xi + F*ui = 0
%   where uiBar is either constant if the input is not subject to uncertainty,
%   or ui if is a decision variable subject to uncertainty.


% - of the inputs to the function, thetaMatrix and u are considered to be the
% nominal ones plus the uncertainty (you use this in the maximization
% problem to do a single step of gradient ascent)
%
% - thetaMatrixHat is the matrix of nominal parameters (the ones from the
% estimate)
%
% - i  is the index of the rate/harvested metabolite
function totalJacobianTranspose = EvaluateTotalJacobianObjectiveConstraints(uncertInputIndexes, uncertThetaIndexes, qExt, cExt, thetaMatrix, thetaMatrixHat, u, i, objectiveType, signObjective, Amac, Xv, F, covMatrix)
    P = pinv(covMatrix);
    jacobianThetaMacrorates         = GetJacobianThetaMacrorates(Amac, cExt, u, thetaMatrix);
    jacobianInputMacrorates         = GetJacobianInputMacrorates(Amac, cExt, u, thetaMatrix);
    jacobianStateMacrorates         = GetJacobianStateMacrorates(Amac, cExt, u, thetaMatrix);
    gradObjective                   = EvaluateObjectiveGradient(uncertInputIndexes, uncertThetaIndexes, objectiveType, i, Xv, F, qExt, signObjective, jacobianInputMacrorates, jacobianStateMacrorates, jacobianThetaMacrorates);
    jacobianEqualityConstraints     = EvaluateEqualityConstraintsJacobian(jacobianThetaMacrorates, jacobianInputMacrorates, jacobianStateMacrorates, uncertInputIndexes, uncertThetaIndexes, cExt, Xv, F);
    jacobianInequalityConstraints   = EvaluateInequalityConstraintsJacobian(uncertInputIndexes, uncertThetaIndexes, cExt, P, thetaMatrix, thetaMatrixHat);
    jacobianConstraints             = [jacobianEqualityConstraints; jacobianInequalityConstraints];
    totalJacobianTranspose                   = [gradObjective, jacobianConstraints']; 
end

function jacobianThetaMacrorates = GetJacobianThetaMacrorates(Amac, cExt, u, thetaMatrix)
    u;
    jacobianThetaMacrorates = ParameterSensitivitiesOfRates(Amac, cExt, thetaMatrix);
end

function jacobianInputMacrorates = GetJacobianInputMacrorates(Amac, cExt, u, thetaMatrix)
    Amac; cExt; u; thetaMatrix;
    jacobianInputMacrorates = zeros(size(Amac,1),length(u));
end

function jacobianStateMacrorates = GetJacobianStateMacrorates(Amac, cExt, u, thetaMatrix)
    u;
    Jw = MacroKineticsJacobian(thetaMatrix, cExt);
    jacobianStateMacrorates = Amac*Jw;
end

function gradObjective = EvaluateObjectiveGradient(uncertInputIndexes, uncertThetaIndexes, objectiveType, i, Xv, F, qExt, signObjective, jacobianInputMacrorates, jacobianStateMacrorates, jacobianThetaMacrorates)

    nablaStateMacrorate = jacobianStateMacrorates(i,:)';
    nablaThetaMacrorate = jacobianThetaMacrorates(i,uncertThetaIndexes)';
    nablaInputMacrorate = jacobianInputMacrorates(i,uncertInputIndexes)';
    nablaStateGrowthrate = jacobianStateMacrorates(end,:)';
    nablaThetaGrowthrate = jacobianThetaMacrorates(end,uncertThetaIndexes)';
    nablaInputGrowthrate = jacobianInputMacrorates(end,uncertInputIndexes)';

    if objectiveType == 1 % rate of interest i.e. g = +- q_i
        gradObjectiveInput      = nablaInputMacrorate*signObjective;
        gradObjectiveState      = nablaStateMacrorate*signObjective;
        gradObjectiveTheta      = nablaThetaMacrorate*signObjective;
    else % harvested amount i.e. +- Xv/F*(F-mu)*q_i
        gradObjectiveInput      = signObjective*(-Xv/F*nablaInputGrowthrate*qExt(i) + Xv/F*(F-qExt(end))*nablaInputMacrorate); 
        gradObjectiveState      = signObjective*(-Xv/F*nablaStateGrowthrate*qExt(i) + Xv/F*(F-qExt(end))*nablaStateMacrorate); 
        gradObjectiveTheta      = signObjective*(-Xv/F*nablaThetaGrowthrate*qExt(i) + Xv/F*(F-qExt(end))*nablaThetaMacrorate); 
    end        

    gradObjective = [gradObjectiveInput;
                     gradObjectiveState;
                     gradObjectiveTheta];
end

function jacobianEqualityConstraints = EvaluateEqualityConstraintsJacobian(jacobianThetaMacrorates, jacobianInputMacrorates, jacobianStateMacrorates, uncertInputIndexes, uncertThetaIndexes, cExt, Xv, F)
    jacobianEqualityConstraintsInput = [];
    jacobianEqualityConstraintsState = [];
    jacobianEqualityConstraintsTheta = [];
    r = zeros(length(cExt),1);
    r(uncertInputIndexes) = 1;
    I = eye(length(cExt));
    for i = 1 : length(cExt)
        gradientInputMBEMetaboliteI = (Xv*jacobianInputMacrorates(i,uncertInputIndexes) + F*I(i,uncertInputIndexes)*r(i))';
        gradientStateMBEMetaboliteI = (Xv*jacobianStateMacrorates(i,:) - F*I(i,:))';
        gradientThetaMBEMetaboliteI = (Xv*jacobianThetaMacrorates(i,uncertThetaIndexes))';
        jacobianEqualityConstraintsInput = [jacobianEqualityConstraintsInput; 
                                            gradientInputMBEMetaboliteI'];
        jacobianEqualityConstraintsState = [jacobianEqualityConstraintsState; 
                                            gradientStateMBEMetaboliteI'];
        jacobianEqualityConstraintsTheta = [jacobianEqualityConstraintsTheta; 
                                            gradientThetaMBEMetaboliteI'];
    end
    jacobianEqualityConstraints = [jacobianEqualityConstraintsInput, jacobianEqualityConstraintsState, jacobianEqualityConstraintsTheta];
end

function jacobianInequalityConstraints = EvaluateInequalityConstraintsJacobian(uncertInputIndexes, uncertThetaIndexes, cExt, P, thetaMatrix, thetaMatrixHat) 
    thetaVec = ConstructParameterVectorFromMatrix(thetaMatrix);
    thetaVecHat = ConstructParameterVectorFromMatrix(thetaMatrixHat);
    % first inequality is quadratic function for uncertainty set i.e. 
    % (th-thHat)'*P*(th-thHat) - rho <= 0
    gradientInequalityConstraintsInputUncSet = zeros(length(uncertInputIndexes),1);
    gradientInequalityConstraintsStateUncSet = zeros(length(cExt),1);
    gradientInequalityConstraintsThetaUncSet = 2*P*(thetaVec(uncertThetaIndexes)-thetaVecHat(uncertThetaIndexes)); % P is the submatrix of the (inverse) covariance matrix relative to the selected parameters 
    gradientInequalityConstraintsUncSet = [gradientInequalityConstraintsInputUncSet;
                                           gradientInequalityConstraintsStateUncSet;
                                           gradientInequalityConstraintsThetaUncSet];
    % second set of inequalities are input uncertainties constraints i.e.
    %  ui - uiHat <= deltaUiUpperBound
    %  - ui + uiHat <= -deltaUiLowerBound
    jacobianInequalityConstraintsInputUncInput = [eye(length(uncertInputIndexes));-eye(length(uncertInputIndexes))];
    jacobianInequalityConstraintsStateUncInput = zeros(length(uncertInputIndexes)*2, length(cExt));
    jacobianInequalityConstraintsThetaUncInput = zeros(length(uncertInputIndexes)*2, length(uncertThetaIndexes));
    jacobianInequalityConstraintsUncInput = [jacobianInequalityConstraintsInputUncInput, jacobianInequalityConstraintsStateUncInput, jacobianInequalityConstraintsThetaUncInput];
    jacobianInequalityConstraints = [gradientInequalityConstraintsUncSet';
                                     jacobianInequalityConstraintsUncInput];
end