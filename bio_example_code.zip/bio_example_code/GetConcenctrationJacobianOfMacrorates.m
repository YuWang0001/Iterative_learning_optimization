function Jw = GetConcenctrationJacobianOfMacrorates(theta, cext)
    n = length(cext);
    nr = size(theta,1);
    Jw = zeros(nr,n);
    for i = 1 : nr
        for j = 1 : n
            
        end
    end
end