function [c,ceq,dc,dceq] = constriants_for_evaluationWG(x,u,id_model,  model_data,opt_data, Index_selected_para,length_selected_para,alpha,medium,qExtNom,cExtNom)
%     mediumNom = medium;
%     mediumNom(opt_data.Index_input_1) = u(1);
%     mediumNom(opt_data.Index_input_2) = u(2);
%     % First x's represent residual concentrations  1-23?
%     % delta: diviation from the identified theta 
%     u_var(1) = u(1) + x(24);
%     u_var(2) = u(2) + x(25);
%     Xv_var = model_data.Xv + x(26);
%     
%     medium(opt_data.Index_input_1) = u_var(1);
%     medium(opt_data.Index_input_2) = u_var(2);
%     delta = [];
%     thetaVector_var = id_model.thetaVector;
%     for i = 1 : length_selected_para
%         delta = [x(i+26) delta];
%         thetaVector_var(Index_selected_para(i)) = id_model.thetaVector(Index_selected_para(i)) + delta(i); 
%     end
%     
%     % define equality constraints: ceq = define_equality_constraint(thetaVector0, cExt, activationPars, nzp, Amac,V,Xv,F,input);
%     thetaMatrix = ConstructParameterMatrixFromVector(thetaVector_var, id_model.nzp, model_data.activationPars);
%     [q,~] = ComputeQExt(x(1:23),thetaMatrix,model_data.Amac);
%     
%     % 1. nominal values for cExt, medium, Xv, rates --> passed as parameters
%     % to this function. cExtNom, mediumNom, XvNom, qExtNom
%     
%     mbeNom = zeros(21,1);
%     for i = 1 : 21
%         mbeNom(i) = qExtNom(i)*model_data.V*model_data.Xv + mediumNom(i)*model_data.F - cExtNom(i)*model_data.F;
%     end
%     mbeNomNorm = mbeNom'*mbeNom;
%     mbe = zeros(21,1);
%     
%     for i = 1 : 21
% %         ceq(i) =  q(i)*model_data.V*Xv_var + medium(i)*model_data.F - x(i)*model_data.F;
%         mbe(i) =  q(i)*model_data.V*Xv_var + medium(i)*model_data.F - x(i)*model_data.F;
%         c((i-1)*3+1) =  q(i) - opt_data.qbound(i,2); % upper bound on rates
%         c((i-1)*3+2) =  -q(i) + opt_data.qbound(i,1); % lower bound on rates     
%         c((i-1)*3+3) =  -x(i); % residual concentration in bioreactor is positive        
%     end
%     % positive parameters?
% %     ceq(22) = q(23)*model_data.V*Xv_var  - x(23)*model_data.F; % mAb  %% Check the number of equality constraint here
%     
% %     % define inequality constraints
%     c(66) =  q(22) - opt_data.qbound(22,2); % upper bound on rates
%     c(67) =  -q(22) + opt_data.qbound(22,1); % lower bound on rates
%     c(68) = -x(22);
%     c(69) =  q(23) - opt_data.qbound(23,2); % upper bound on rates
%     c(70) =  -q(23) + opt_data.qbound(23,1); % lower bound on rates
%     c(71) = -x(23);
%     for i = 1 : length_selected_para
%        c(71+i) = -thetaVector_var(Index_selected_para(i));
%     end
%     
%  
%     c(71+length_selected_para+1) = delta*(inv(id_model.covMatrix_reduced))*delta' - chi2inv(0.95,length_selected_para)*alpha;
%     
%     % input uncertainties
%     c(71+length_selected_para+1 + 1) = - x(24) + u(1)*(-opt_data.percErrMedium);
%     c(71+length_selected_para+1 + 2) =  x(24) - u(1)*(opt_data.percErrMedium);
%     c(71+length_selected_para+1 + 3) = - x(25) + u(2)*(-opt_data.percErrMedium);
%     c(71+length_selected_para+1 + 4) =  x(25) - u(2)*(opt_data.percErrMedium);
%     c(71+length_selected_para+1 + 5) = - x(26) + model_data.Xv*(-opt_data.Xv_variation);
%     c(71+length_selected_para+1 + 6) =  x(26) - model_data.Xv*(opt_data.Xv_variation);
%     c(71+length_selected_para+1 + 7) = mbe'*mbe - mbeNomNorm*10;
% % %     % constraints with robust satisfaction
% %     c(71+length_selected_para+1 + 7) =   q(opt_data.constraint_of_interest(1)) - opt_data.constraint_bounds(1);
% %     c(71+length_selected_para+1 + 8) =   q(opt_data.constraint_of_interest(2)) - opt_data.constraint_bounds(2);
%     ceq = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 mediumNom = medium;
    mediumNom(opt_data.Index_input_1) = u(1);
    mediumNom(opt_data.Index_input_2) = u(2);
    % First x's represent residual concentrations  1-23?
    % delta: diviation from the identified theta 
    u_var(1) = u(1);
    u_var(2) = u(2);
    Xv_var = model_data.Xv;
    
    medium(opt_data.Index_input_1) = u_var(1);
    medium(opt_data.Index_input_2) = u_var(2);
    delta = [];
    thetaVector_var = id_model.thetaVector;
    for i = 1 : length_selected_para
%         delta = [x(i+23) delta];
        delta = [delta, x(i+23)];
        thetaVector_var(Index_selected_para(i)) = id_model.thetaVector(Index_selected_para(i)) + delta(i); 
    end
    thetaMatrix = ConstructParameterMatrixFromVector(thetaVector_var, id_model.nzp, model_data.activationPars);
%     cRes = RunSingleExperiment2(medium,model_data.Amac,thetaMatrix,model_data.Xv,model_data.F,0,0,0,0,cExtNom);
    
%     [q,~] = ComputeQExt(x(1:23),thetaMatrix,model_data.Amac);
    [q,~] = ComputeQExt(x(1:23),thetaMatrix,model_data.Amac); 
    
    % 1. nominal values for cExt, medium, Xv, rates --> passed as parameters
    % to this function. cExtNom, mediumNom, XvNom, qExtNom
    
%     mbeNom = zeros(21,1);
%     for i = 1 : 21
%         mbeNom(i) = qExtNom(i)*model_data.V*model_data.Xv + mediumNom(i)*model_data.F - cExtNom(i)*model_data.F;
%     end
%     mbeNomNorm = mbeNom'*mbeNom;
%     mbe = zeros(21,1);
    JxW = MacroKineticsJacobianOldEff(thetaMatrix,x(1:23));
    JthW = JacobianThetaWEff(x(1:23), thetaMatrix, id_model.nzp);
%     JxMBE = (model_data.Xv*model_data.Amac*JxW-model_data.F*eye(length(cRes)));
%     JthMBE = (model_data.Xv*model_data.Amac*JthW);
% %     JthX = -inv(JxMBE)*JthMBE;
%     JthX = JthX(:,Index_selected_para);
    JxQ = model_data.Amac*JxW;
    JthQ = model_data.Amac*JthW;
    JthQ = JthQ(:,Index_selected_para);
    

    for i = 1 : 21
%         ceq(i) =  q(i)*model_data.V*Xv_var + medium(i)*model_data.F - x(i)*model_data.F;
%         mbe(i) =  q(i)*model_data.V*Xv_var + medium(i)*model_data.F - x(i)*model_data.F;
       
        c((i-1)*2+1) =  q(i) - opt_data.qbound(i,2); % upper bound on rates
        dc(:,(i-1)*2+1) = [ JxQ(i,:)';
                            JthQ(i,:)'];
%         dc(:,(i-1)*2+1) =
        c((i-1)*2+2) =  -q(i) + opt_data.qbound(i,1); % lower bound on rates     
        dc(:,(i-1)*2+2) = -[ JxQ(i,:)';
                            JthQ(i,:)'];
%         c((i-1)*3+3) =  -x(i); % residual concentration in bioreactor is positive
%         c((i-1)*5+3) =  -x(i) + 0*(id_model.cExtMat_base_medium(i)); % residual concentration in bioreactor is positive 
%         c((i-1)*5+4) =  x(i) - 50000*(id_model.cExtMat_base_medium(i)); % residual concentration in bioreactor is positive
%         c((i-1)*5+3) =  -x(i) + 0*(id_model.cExtMat_base_medium(i)); % residual concentration in bioreactor is positive 
%         c((i-1)*5+4) =  x(i) - 50000*(id_model.cExtMat_base_medium(i)); % residual concentration in bioreactor is positive
%         c((i-1)*5+5) =  (q(i)*model_data.V*Xv_var + medium(i)*model_data.F - x(i)*model_data.F).^2 - mbeNom(i).^2;
    end
    % positive parameters?
%     ceq(22) = q(23)*model_data.V*Xv_var  - x(23)*model_data.F; % mAb  %% Check the number of equality constraint here
    
%     % define inequality constraints
    c(43) =  q(22) - opt_data.qbound(22,2); % upper bound on rates
    dc(:,43) = [JxQ(22,:)';
                JthQ(22,:)'];

    c(44) =  -q(22) + opt_data.qbound(22,1); % lower bound on rates
    dc(:,44) = -[JxQ(22,:)';
                JthQ(22,:)'];
%     c(45) = -x(22);
    c(45) =  q(23) - opt_data.qbound(23,2); % upper bound on rates
    dc(:,45) = [JxQ(23,:)';
                JthQ(23,:)'];
    c(46) =  -q(23) + opt_data.qbound(23,1); % lower bound on rates
    dc(:,46) = -[JxQ(23,:)';
                JthQ(23,:)'];
%     c(111) = -x(23);
    I = eye(length(Index_selected_para));
%   thetaVector_var(Index_selected_para(i)) = id_model.thetaVector(Index_selected_para(i)) + delta(i); 

    for i = 1 : length_selected_para
       c(46+i) = -thetaVector_var(Index_selected_para(i));
       dc(:,46+i) = [   zeros(23,1);
                        -I(:,i)];
    end
    
 
    c(46+length_selected_para+1) = delta*(inv(id_model.covMatrix_reduced))*delta' - chi2inv(0.95,length_selected_para)*alpha;
    dc(:,46+length_selected_para+1) = [zeros(23,1);
                                        2*(inv(id_model.covMatrix_reduced))*delta'];
    % input uncertainties
%     c(71+length_selected_para+1 + 1) = - x(24) + u(1)*(-opt_data.percErrMedium);
%     c(71+length_selected_para+1 + 2) =  x(24) - u(1)*(opt_data.percErrMedium);
%     c(71+length_selected_para+1 + 3) = - x(25) + u(2)*(-opt_data.percErrMedium);
%     c(71+length_selected_para+1 + 4) =  x(25) - u(2)*(opt_data.percErrMedium);
%     c(71+length_selected_para+1 + 5) = - x(26) + model_data.Xv*(-opt_data.Xv_variation);
%     c(71+length_selected_para+1 + 6) =  x(26) - model_data.Xv*(opt_data.Xv_variation);
%     c(91+length_selected_para+1 + 1) = mbe'*mbe - mbeNomNorm*1;
% %     % constraints with robust satisfaction
%     c(71+length_selected_para+1 + 7) =   q(opt_data.constraint_of_interest(1)) - opt_data.constraint_bounds(1);
%     c(71+length_selected_para+1 + 8) =   q(opt_data.constraint_of_interest(2)) - opt_data.constraint_bounds(2);
    
%     c = 
    c = [c,-x(1:23)];
    dc = [dc, [-eye(23);
                zeros(length_selected_para,23)]];
    ceq = model_data.Xv*q(1:end-2)-model_data.F*x(1:21)'+model_data.F*medium(1:21);
    dceq = [model_data.Xv*JxQ(1:end-2,1:end-2)-model_data.F*eye(21),zeros(21,2),model_data.Xv*JthQ(1:end-2,:)]';
%     ceq(end+1) = delta - (0.1);
%    1;

end
