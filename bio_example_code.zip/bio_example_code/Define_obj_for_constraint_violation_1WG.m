function [obj_for_evaluation, grad_obj_for_evaluation] = Define_obj_for_constraint_violation_1WG(x,u,id_model,  model_data,opt_data, Index_selected_para,length_selected_para, medium, cExtNom)

    delta = [];
    thetaVector_var = id_model.thetaVector;
    for i = 1 : length_selected_para
        delta = [delta, x(i+23)];
        thetaVector_var(Index_selected_para(i)) = id_model.thetaVector(Index_selected_para(i)) + delta(i); 
    end
    thetaMatrix = ConstructParameterMatrixFromVector(thetaVector_var, id_model.nzp, model_data.activationPars);
    JxW = MacroKineticsJacobianOldEff(thetaMatrix,x(1:23));
    JthW = JacobianThetaWEff(x(1:23), thetaMatrix, id_model.nzp);

    nablaxq = (model_data.Amac(opt_data.constraint_of_interest(1),:)*JxW)';
    JthQ = model_data.Amac*JthW;
    nablathq = JthQ(opt_data.constraint_of_interest(1),Index_selected_para)';

    obj_for_evaluation = -x(opt_data.constraint_of_interest(1))+opt_data.constraint_bounds(1);  
    grad_obj_for_evaluation = [-nablaxq*model_data.Xv/model_data.F;
                               -nablathq*model_data.Xv/model_data.F];
end
