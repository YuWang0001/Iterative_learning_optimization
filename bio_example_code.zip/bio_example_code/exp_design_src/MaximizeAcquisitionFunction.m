% Maximize the weighted expected improvement acquisition function to find
% the location for the new experiment

function [u_max_acquisition, acquisition_function_max] = MaximizeAcquisitionFunction(best_worst_case, f_explored_ub, f_explored_lb, u_explored,u_exlored_coarse_search,f_explored_ub_coarse_search,f_explored_lb_coarse_search)
    mean_diff_with_robust_opt = -(best_worst_case - ([f_explored_ub;f_explored_ub_coarse_search'] + [f_explored_lb;f_explored_lb_coarse_search'])/2);
    var = ([f_explored_ub;f_explored_ub_coarse_search'] - [f_explored_lb;f_explored_lb_coarse_search']);
    acquisition_function =  mean_diff_with_robust_opt.*var;
    
    acquisition_function_max = max(acquisition_function);
    max_acquisition_function_ind = find(acquisition_function==acquisition_function_max);
    if length(max_acquisition_function_ind) > 1
        max_acquisition_function_ind  = max_acquisition_function_ind(1);
    end
    u_explored_all = [u_explored,u_exlored_coarse_search];
    u_max_acquisition = u_explored_all(:,max_acquisition_function_ind);
end