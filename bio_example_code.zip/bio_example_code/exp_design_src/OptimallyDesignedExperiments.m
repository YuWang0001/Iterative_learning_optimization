function u_new_sequence = OptimallyDesignedExperiments(stopping_eps, N_exp, sigma, u_max_acquisition, acquisition_function_max, robust_optimum_input, input_bounds)
    x_new_sequence = []; u_new_sequence = [];
    m = length(u_max_acquisition);
    if (acquisition_function_max>0)
        n_generated = 0;
        while n_generated < N_exp
            new_input = u_max_acquisition + sigma*(-1 + 2*rand());
            if ~(new_input(1) < input_bounds(1,1) || new_input(1) > input_bounds(1,2) || new_input(2) < input_bounds(2,1) || new_input(2) > input_bounds(2,2))
                u_new_sequence = [u_new_sequence, new_input];
                n_generated = n_generated + 1;
            end
        end
    end
end

function u_sat = SaturateInput(u_list, u_bounds)
    u_sat = u_list;
    for k = 1 : size(u_list,2)
        u = u_list(:,k);
        for i = 1 : length(u)
            if u(i) <= u_bounds(i,1)
                u(i) = u_bounds(i,1);
            elseif u(i) >= u_bounds(i,2)
                u(i) = u_bounds(i,2);
            end
        end
        u_sat(:,k) = u;
    end
end