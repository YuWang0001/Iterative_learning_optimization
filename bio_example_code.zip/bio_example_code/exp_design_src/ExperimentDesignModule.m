% ed_result = ExperimentDesignModule(ro_result)
% Should return the input where the next experiment(s) should be
% performed
% 
%   @input: 
%       ro_result : this is a data structure with all the results from robust
%                   optimization (see RobustOptimizationModule for details
%                   on the data structure)
%
%   @output:
%       ed_result : this is a data structure with the result from
%                   experiment design.
%                   ed_result.experiment_design_input : the next input
%                   based on experiment design;
%                   ed_result.acquisition_function_max : the acquisition
%                   function value at the designed new input

function ed_result = ExperimentDesignModule(ro_result)
    best_worst_case = ro_result.best_worst_case;
    f_explored_ub = ro_result.f_explored_ub;
    f_explored_lb = ro_result.f_explored_lb;
    u_explored = ro_result.u_explored;
    [experiment_design_input, acquisition_function_max] = MaximizeAcquisitionFunction(best_worst_case, f_explored_ub, f_explored_lb, u_explored);
    ed_result.experiment_design_input = experiment_design_input;
    ed_result.acquisition_function_max = acquisition_function_max;
end