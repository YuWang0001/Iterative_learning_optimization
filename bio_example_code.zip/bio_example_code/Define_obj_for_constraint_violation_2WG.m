function [obj_for_evaluation, grad_obj_for_evaluation] = Define_obj_for_constraint_violation_2WG(x,u,id_model,  model_data,opt_data, Index_selected_para,length_selected_para, medium, cExtNom)

    % First x's represent residual concentrations that are of interest
    % delta: diviation from the identified theta, i.e., realizations in
    % uncertainty set

%     delta = [];
%     thetaVector_var = id_model.thetaVector;
%     for i = 1 : length_selected_para
%         delta = [x(i+26) delta];
%         thetaVector_var(Index_selected_para(i)) = id_model.thetaVector(Index_selected_para(i)) + delta(i); 
%     end
%     thetaMatrix = ConstructParameterMatrixFromVector(thetaVector_var, id_model.nzp, model_data.activationPars);
%     [q,~] = ComputeQExt(x(1:23),thetaMatrix,model_data.Amac); 
% 
%     obj_for_evaluation = (model_data.F-q(22))*q(23);  
    delta = [];
    thetaVector_var = id_model.thetaVector;
    for i = 1 : length_selected_para
%         delta = [x(i+23) delta];
        delta = [delta, x(i+23)];
        thetaVector_var(Index_selected_para(i)) = id_model.thetaVector(Index_selected_para(i)) + delta(i); 
    end
    thetaMatrix = ConstructParameterMatrixFromVector(thetaVector_var, id_model.nzp, model_data.activationPars);
%     cRes = RunSingleExperiment2(medium,model_data.Amac,thetaMatrix,model_data.Xv,model_data.F,0,0,0,0, cExtNom);
    JxW = MacroKineticsJacobianOldEff(thetaMatrix,x(1:23));
    JthW = JacobianThetaWEff(x(1:23), thetaMatrix, id_model.nzp);
%     JxMBE = (model_data.Xv*model_data.Amac*JxW-model_data.F*eye(length(cRes)));
%     JthMBE = (model_data.Xv*model_data.Amac*JthW);
%     JthX = -inv(JxMBE)*JthMBE;
%     JthX = JthX(:,Index_selected_para);
%     nablaxMu = (model_data.Amac(22,:)*JxW)';
%     nablaxqMab = (model_data.Amac(23,:)*JxW)';
%     JthQ = model_data.Amac*JthW;
%     nablathMu = JthQ(22,Index_selected_para)';
%     nablathqMab = JthQ(23,Index_selected_para)';
    
    nablaxq = (model_data.Amac(opt_data.constraint_of_interest(2),:)*JxW)';
    JthQ = model_data.Amac*JthW;
    nablathq = JthQ(opt_data.constraint_of_interest(2),Index_selected_para)';

%     [q,~] = ComputeQExt(x(1:23),thetaMatrix,model_data.Amac); 
    [q,~] = ComputeQExt(x(1:23),thetaMatrix,model_data.Amac); 
%     Jcw = 
    obj_for_evaluation = -q(opt_data.constraint_of_interest(2))+opt_data.constraint_bounds(2);  
    grad_obj_for_evaluation = [-nablaxq;
                               -nablathq];
end
