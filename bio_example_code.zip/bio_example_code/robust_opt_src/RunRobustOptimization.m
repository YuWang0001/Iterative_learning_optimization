function [best_obj_robust_optimum_input,robust_optimum_input, robust_optimum_value, u_hist,f_explored_lb, f_explored_ub_current, u_explored_current,constraint_violation_direction_hist,u_hist_matrix, worst_case_vec] = RunRobustOptimization(initial_inputs, no_steps,  id_model, opt_data, model_data,Index_selected_para,length_selected_para,medium,u_exlored_coarse_search,f_explored_ub_coarse_search,f_explored_lb_coarse_search)
    % Storage variables
    u_hist = []; u_hist_matrix = [];

    worst_case_vec = [];
    u_explored_current = [];
    f_explored_ub_current = [];
    f_explored_lb = [];
    constraint_violation_direction_hist = [];
    u_converged = [];
    f_converged = [];

    m = size(initial_inputs,1); % input dimension
    wb = waitbar(0,'Starting Robust Optimization');
    figure();
    hold on
    grid on
    for j = 1 : size(initial_inputs,2) % total no. of different starting points in the input space

        u_init = initial_inputs(:,j);
        u_current = u_init;
        u_next = u_current;
        color_of_dots = rand(1,3);
        waitbar(j/length(initial_inputs),wb,strcat('Optimization from initial input # ',' ',num2str(j)));
        for i = 1 : no_steps
            waitbar(i/no_steps, wb, strcat('Step #',' ',num2str(i),', Initial input number',' ',num2str(j)));
            [u_next,f_next,u_p_plus,u_p_minus,f_p_plus_ub,f_p_minus_ub, f_p_plus_lb,f_p_minus_lb,constraint_violation_direction] = ...
                RobustOptimizationSingleStep(u_current,id_model, opt_data, model_data, Index_selected_para,length_selected_para,medium);
            u_next = DirectionPreservingSaturation(u_current, opt_data.input_bounds, opt_data.a_k,(u_next - u_current)/opt_data.a_k );
            u_past = u_current;
            u_current = u_next;
            worst_case_current = f_next;

            u_explored_current = [u_explored_current u_p_minus u_p_plus];
            f_explored_ub_current = [f_explored_ub_current;f_p_minus_ub;f_p_plus_ub];
            f_explored_lb = [f_explored_lb;f_p_minus_lb;f_p_plus_lb];
            constraint_violation_direction_hist = [constraint_violation_direction_hist constraint_violation_direction];

            u_hist = [u_hist,u_current]
            u_hist_matrix{j,end+1} = [u_current];
            worst_case_vec = [worst_case_vec;worst_case_current]
            % Stopping criterion
            norm(u_past-u_current,2);
            if norm((u_past-u_current)/opt_data.a_k,2) <= 1e-5
                break
            end
        end
        u_converged = [u_converged, u_current];
        f_converged = [f_converged, worst_case_current];
    end

    robust_optimum_value = max([f_converged,f_explored_lb_coarse_search]);
    best_worst_case_ind = find([f_converged,f_explored_lb_coarse_search]==robust_optimum_value);
    if length(best_worst_case_ind) > 1
        best_worst_case_ind = best_worst_case_ind(1);
    end

    u_converged_all = [u_converged,u_exlored_coarse_search];
    robust_optimum_input = u_converged_all(:,best_worst_case_ind);
    [~,best_obj_robust_optimum_input,~] = obtain_best_case_obj_functionWG(robust_optimum_input,id_model, model_data, opt_data, Index_selected_para,length_selected_para,medium);
end

function u = SaturateInput(u, u_bounds)
    for i = 1 : length(u)
        if u(i) <= u_bounds(i,1)
            u(i) = u_bounds(i,1);
        elseif u(i) >= u_bounds(i,2)
            u(i) = u_bounds(i,2);
        end
    end
end

function uPlus = DirectionPreservingSaturation(u, input_bounds, a_k, d_k)
    a1_bar_plus = a_k;
    a1_bar_minus = a_k;
    a2_bar_minus = a_k;
    a2_bar_plus = a_k;
    if (u(1)+a_k*d_k(1) > input_bounds(1,2))
        a1_bar_plus = (input_bounds(1,2)-u(1))/abs(d_k(1));
    end
    if (u(2)+a_k*d_k(2) > input_bounds(2,2))
        a2_bar_plus =  (input_bounds(2,2)-u(2))/abs(d_k(2));
    end
    if (u(1)+a_k*d_k(1) < input_bounds(1,1))
        a1_bar_minus = (u(1) - input_bounds(1,1))/abs(d_k(1));
    end
    if(u(2)+a_k*d_k(2) < input_bounds(2,1))
        a2_bar_minus = (u(2) - input_bounds(2,1))/abs(d_k(2));
    end
    a_bar = min([a1_bar_plus,a2_bar_plus,a1_bar_minus, a2_bar_minus, a_k]);
    uPlus = u + a_bar*d_k;
end
