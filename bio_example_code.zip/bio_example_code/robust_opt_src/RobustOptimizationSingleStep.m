%% RobustOptimizationSingleStep
%   Run a single step of the robust optimization algorithm using local
%   search with constraint violation avoidance. It works in two phases:
%   1. Check if for a set of perturbed inputs from the actual one, there is
%      any possible violation. If there is, add the input to a set of
%      problematic points;
%   2. If this set of problematic points is non-empty, then the update
%      direction is the one that points away from this set (solves a
%      SOCP). Otherwise approximate the gradient of the worst cost
%      function and moves towards that.
%
%
%   References : 
%               (1) Bertsimas et al. - Nonconvex Robust Optimization for
%               Problem with Constraints - 2009
%               (2) Wang et al. - Model-based feedback mechanism for robust
%               nonconvex optimization with application to optimizing
%               continuous pharmaceutical production - 2022
%

%% Code to run local search
function [u_next,f_next,u_p_plus_temp,u_p_minus_temp,f_p_plus_ub,f_p_minus_ub, f_p_plus_lb,f_p_minus_lb,constraint_violation_direction] = RobustOptimizationSingleStep(u, id_model, opt_data, model_data, Index_selected_para,length_selected_para,medium)
    % Input: m -- size of input u; n -- number of parameters in the model
    % First, define the perturbed input
    m = length(u);
    E = [1 0.1; 0.1 1];
    u_p_plus = u + opt_data.c_k*E;
    u_p_minus = u - opt_data.c_k*E;
    % Initialize vectors
    f_p_plus_ub = [];
    f_p_minus_ub = [];
    f_p_plus_lb = [];
    f_p_minus_lb = [];
    d = [];
    g_p_plus = [];
    g_p_minus = [];
    c_k_vect = opt_data.c_k*ones(m,2);
    [u_p_minus, u_p_plus, constraint_violation_direction, c_k_vect] = FindViolatingInputDirectionsGS(u_p_minus, u_p_plus,  u, c_k_vect, id_model, opt_data, model_data, Index_selected_para,length_selected_para,medium);
    [f_p_minus_lb, f_p_plus_lb, f_p_minus_ub, f_p_plus_ub, c_k_vect, u_p_plus_temp, u_p_minus_temp, f_current] = EvaluateExploredInputsBestWorstCasesGS(u_p_minus, u_p_plus, c_k_vect, u, id_model, opt_data, model_data, Index_selected_para,length_selected_para,medium,constraint_violation_direction);
    constraint_violation_direction = [constraint_violation_direction, u_p_plus_temp(:,find(-f_current <= -f_p_plus_lb)), u_p_minus_temp(:,find(-f_current <= -f_p_minus_lb))];
    beta_epsilon = 0.01;
    [u_next, f_next] = ConstraintsViolationAvoidanceStep(u, constraint_violation_direction, beta_epsilon,id_model, opt_data, model_data, Index_selected_para,length_selected_para,medium);
end

function [u_p_minus, u_p_plus, violating_input_directions, c_k_vect] = FindViolatingInputDirectionsGS(u_p_minus, u_p_plus,  u, c_k_vect, id_model, opt_data, model_data, Index_selected_para,length_selected_para,medium)
    violating_input_directions = [];
    E = eye(length(u));
    for i = 1 : size(u_p_minus, 2)
        max_rescaling_times = 3; % number of times it tries to rescale c_k before continuing
        if OutOfBounds(u_p_minus(:,i),opt_data.input_bounds)
            violating_input_directions = [violating_input_directions, u_p_minus(:,i)];
            continue
        else
            viol = CheckInequalityConstraintViolationGS(u_p_minus(:,i), id_model, opt_data, model_data, Index_selected_para,length_selected_para,medium);
        end
        if viol == 1
            violating_input_directions = [violating_input_directions, u_p_minus(:,i)];
        end
    end
    for i = 1 : size(u_p_plus, 2)
        max_rescaling_times = 3; % number of times it tries to rescale c_k before continuing
        if OutOfBounds(u_p_plus(:,i),opt_data.input_bounds)
            violating_input_directions = [violating_input_directions, u_p_plus(:,i)];
            continue
        else
            viol = CheckInequalityConstraintViolationGS(u_p_plus(:,i), id_model, opt_data, model_data, Index_selected_para,length_selected_para,medium);
        end
        if viol == 1
            violating_input_directions = [violating_input_directions, u_p_plus(:,i)];
        end
    end
end


function viol = CheckInequalityConstraintViolationGS(u, id_model, opt_data, model_data, Index_selected_para,length_selected_para,medium)    
    [~,fval_constraint_violation_1,exitflag_constraint_1] = obtain_obj_for_constraint_violation_1WG(u,id_model, model_data, opt_data, Index_selected_para,length_selected_para,medium);
    [~,fval_constraint_violation_2,exitflag_constraint_2] = obtain_obj_for_constraint_violation_2WG(u,id_model, model_data, opt_data, Index_selected_para,length_selected_para,medium);

    viol = 0;
    if (fval_constraint_violation_1 < 0) || (fval_constraint_violation_2 < 0)
        viol = 1;
    end
end

function [f_p_minus_lb, f_p_plus_lb, f_p_minus_ub, f_p_plus_ub, c_k_vect, u_p_plus_temp, u_p_minus_temp, f_current] = EvaluateExploredInputsBestWorstCasesGS(u_p_minus, u_p_plus,  c_k_vect, u, id_model, opt_data, model_data, Index_selected_para,length_selected_para,medium,constraint_violation_direction)
    f_p_minus_lb = [];
    f_p_plus_lb = [];
    f_p_minus_ub = [];
    f_p_plus_ub =[];
    u_p_plus_temp = [];
    u_p_minus_temp = [];


    for i = 1 : size(u_p_minus, 2)

        u_temp = u_p_plus(:,i);

        if isempty(constraint_violation_direction)
            u_p_plus_temp = [u_p_plus_temp,u_p_plus(:,i)];
            % UB and LB with u_p_plus(:,i)
            [~,fval,exitflag] = obtain_best_case_obj_functionWG(u_p_plus(:,i),id_model, model_data, opt_data, Index_selected_para,length_selected_para,medium);
            f_p_plus_ub = [f_p_plus_ub;value(fval)];

            [~,fval,exitflag] = obtain_worst_case_obj_functionWG(u_p_plus(:,i),id_model,  model_data, opt_data, Index_selected_para,length_selected_para,medium);
            f_p_plus_lb  = [f_p_plus_lb;value(fval)];
        elseif sum(constraint_violation_direction(1,:) == u_temp(1,:) & constraint_violation_direction(2, :) == u_temp(2,:)) == 0
            u_p_plus_temp = [u_p_plus_temp,u_p_plus(:,i)];
            % UB and LB with u_p_plus(:,i)
            [~,fval,exitflag] = obtain_best_case_obj_functionWG(u_p_plus(:,i),id_model, model_data, opt_data, Index_selected_para,length_selected_para,medium);
            f_p_plus_ub = [f_p_plus_ub;value(fval)];

            [~,fval,exitflag] = obtain_worst_case_obj_functionWG(u_p_plus(:,i),id_model,  model_data, opt_data, Index_selected_para,length_selected_para,medium);
            f_p_plus_lb  = [f_p_plus_lb;value(fval)];
        end


        % UB and LB with u_p_minus(:,i)
        u_temp = u_p_minus(:,i);
        if isempty(constraint_violation_direction)
            u_p_minus_temp = [u_p_minus_temp,u_p_minus(:,i)];
            [~,fval,exitflag] = obtain_best_case_obj_functionWG(u_p_minus(:,i),id_model, model_data, opt_data, Index_selected_para,length_selected_para,medium);
            f_p_minus_ub = [f_p_minus_ub;value(fval)];

            [~,fval,exitflag] = obtain_worst_case_obj_functionWG(u_p_minus(:,i),id_model,  model_data, opt_data, Index_selected_para,length_selected_para,medium);
            f_p_minus_lb = [f_p_minus_lb;value(fval)];
        elseif sum(constraint_violation_direction(1,:) == u_temp(1,:) & constraint_violation_direction(2, :) == u_temp(2,:)) == 0
            u_p_minus_temp = [u_p_minus_temp,u_p_minus(:,i)];
            [~,fval,exitflag] = obtain_best_case_obj_functionWG(u_p_minus(:,i),id_model, model_data, opt_data, Index_selected_para,length_selected_para,medium);
            f_p_minus_ub = [f_p_minus_ub;value(fval)];

            [~,fval,exitflag] = obtain_worst_case_obj_functionWG(u_p_minus(:,i),id_model,  model_data, opt_data, Index_selected_para,length_selected_para,medium);
            f_p_minus_lb = [f_p_minus_lb;value(fval)];
        end


    end
    [~,fval,exitflag] = obtain_worst_case_obj_functionWG(u,id_model,  model_data, opt_data, Index_selected_para,length_selected_para,medium);
    f_current = value(fval);
end

function [u_next, f_next] = ConstraintsViolationAvoidanceStep(u, constraint_violation_direction, beta_epsilon,id_model, opt_data, model_data, Index_selected_para,length_selected_para,medium)
    u
    constraint_violation_direction
    m = length(u);
    d_feas = sdpvar(m,1);
    beta  = sdpvar(1,1);
    objective = beta;
    constraints = [norm(d_feas,2) <= 1, beta <= -beta_epsilon];
    if isempty(constraint_violation_direction)
        d_feas_value = [1;1];
    elseif length(constraint_violation_direction) > 3
        d_feas_value = [0;0];
    else
        for i = 1 : size(constraint_violation_direction,2)
            constraints = [constraints;...
                d_feas'*((constraint_violation_direction(:,i)*0.95-u))/norm(constraint_violation_direction(:,i)-u,2) <= beta];
        end

        options = sdpsettings('solver','gurobi');
        sol = optimize(constraints,objective,options);
        d_feas_value = value(d_feas)
    end

    u_next = u + opt_data.a_k*d_feas_value;

    % Finding the worst case associated to u_next
    [~,fval,exitflag] = obtain_worst_case_obj_functionWG(u_next,id_model,  model_data, opt_data, Index_selected_para,length_selected_para,medium);
    f_next = value(fval);
end

function tf = OutOfBounds(u,input_bounds)
    for i = 1 : length(u)
        if (u(i) < input_bounds(i,1)) || (u(i) > input_bounds(i,2))
            tf = 1;
            return;
        end
    end
    tf = 0;
end
